<?php
    /*
    Plugin Name: Mi Tarificador de Aislamientos
    Plugin URI: https://www.webcafeina.com
    Description: Un tarificador para aislamientos térmicos y acústicos.
    Version: 1.1.1
    Author: Álvaro Cabezas Campos
    Author URI: https://www.example.com
    License: GPL2
    */

    $tipo_usuario = sanitize_text_field($_GET["mode"]);
    $action = sanitize_text_field($_GET["action"]);
    $id_holded = sanitize_text_field($_GET["id"]);

    // INCLUIMOS DASHICONS
    add_action( 'wp_enqueue_scripts', 'dashicons_front_end' );
    function dashicons_front_end() {
        wp_enqueue_style( 'dashicons' );
    }

    // PÁGINA DE CONFIGURACIÓN DEL PLUGIN
    function mi_tarificador_register_options_page() {
        add_menu_page(
          'Configuración del Tarificador', // Título de la página
          'Tarificador', // Título del menú
          'manage_options', // Capacidad requerida
          'mi-tarificador', // Identificador de menú único
          'mi_tarificador_options_page', // Función que muestra el contenido de la página
          'dashicons-money-alt', // Icono del menú
          12 // Posición en el menú
        );
    }
    add_action('admin_menu', 'mi_tarificador_register_options_page');

    function mi_tarificador_options_page() {
        ?>
        <div class="wrap">
          <h1>Configuración del Tarificador</h1>
          <h2>Panel de administración del plugin tarificador</h2>
          <h4 style="font-style: italic">Creado con &hearts; por Webcafeina para Eccoaisla</h4>
          <h3 style="font-weight: bold">PRECAUCIÓN: modificar estos datos supone la modificación de la lógica del plugin. Proceda con cuidado.</h3>
          <form action="options.php" method="post">
            <?php
                settings_fields('mi_tarificador_options_group');
                do_settings_sections('mi_tarificador');
                submit_button();
            ?>
          </form>
        </div>
        <?php
    }

    function mi_tarificador_register_settings() {
        register_setting(
          'mi_tarificador_options_group', // Grupo de opciones
          'mi_tarificador_options' // Nombre de la opción
        );
      
        add_settings_section(
          'mi_tarificador_general_section', // ID de la sección
          'Configuración general', // Título de la sección
          null, // Función de devolución de llamada de la sección (opcional)
          'mi_tarificador' // ID de la página
        );
      
        add_settings_field(
          'mi_tarificador_webhook_url', // ID del campo
          'URL del webhook de Zapier', // Título del campo
          'mi_tarificador_webhook_url_callback', // Función de devolución de llamada del campo
          'mi_tarificador', // ID de la página
          'mi_tarificador_general_section' // ID de la sección
        );

        add_settings_field(
            'mi_tarificador_precio_fachada',
            'Precio por m² para aislar la fachada (€)',
            'mi_tarificador_precio_fachada_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );

        add_settings_field(
            'mi_tarificador_precio_minimo_ruidos',
            'Precio mínimo a presupuestar por ruidos (€)',
            'mi_tarificador_precio_minimo_ruidos_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );

        add_settings_field(
            'mi_tarificador_precio_metros_ruidos',
            'Precio por m² a presupuestar por ruidos (€)',
            'mi_tarificador_precio_metros_ruidos_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );

        add_settings_field(
            'mi_tarificador_precio_forjado_hasta130',
            'Precio de mano de obra de forjado hasta 130 m² de tejado (€)',
            'mi_tarificador_precio_forjado_hasta130_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );

        add_settings_field(
            'mi_tarificador_precio_forjado_desde130',
            'Precio de mano de obra de forjado a partir de 130 m² de tejado (€)',
            'mi_tarificador_precio_forjado_desde130_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );

        add_settings_field(
            'mi_tarificador_precio_falsosTechos_hasta60',
            'Precio de mano de obra de falsos techos hasta 60 m² de tejado (€)',
            'mi_tarificador_precio_falsosTechos_hasta60_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );

        add_settings_field(
            'mi_tarificador_precio_falsosTechos_desde60',
            'Precio de mano de obra de falsos techos a partir de 60 m² de tejado (€)',
            'mi_tarificador_precio_falsosTechos_desde60_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );

        add_settings_field(
            'mi_tarificador_precio_general_hasta20',
            'Precio de mano de obra hasta 20 m² de paredes (€)',
            'mi_tarificador_precio_general_hasta20_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );

        add_settings_field(
            'mi_tarificador_precio_general_desde20hasta50',
            'Precio de mano de obra desde 20 m² hasta 50 m² de paredes (€)',
            'mi_tarificador_precio_general_desde20hasta50_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );

        add_settings_field(
            'mi_tarificador_precio_general_desde50hasta100',
            'Precio de mano de obra desde 50 m² hasta 100 m² de paredes (€)',
            'mi_tarificador_precio_general_desde50hasta100_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );

        add_settings_field(
            'mi_tarificador_precio_general_desde100',
            'Precio de mano de obra a partir 100 m² de paredes (€)',
            'mi_tarificador_precio_general_desde100_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );

        add_settings_field(
            'mi_tarificador_potenciador_lanaRoca',
            'Potenciador de presupuesto por usar lana de roca',
            'mi_tarificador_potenciador_lanaRoca_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );

        add_settings_field(
            'mi_tarificador_potenciador_lanaMineral',
            'Potenciador de presupuesto por usar lana mineral',
            'mi_tarificador_potenciador_lanaMineral_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );

        add_settings_field(
            'mi_tarificador_precio_kitIluminacion_DS160',
            'Precio del kit de iluminación DS160 (€)',
            'mi_tarificador_precio_kitIluminacion_DS160_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );

        add_settings_field(
            'mi_tarificador_precio_kitIluminacion_DS290',
            'Precio del kit de iluminación DS290 (€)',
            'mi_tarificador_precio_kitIluminacion_DS290_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );

        add_settings_field(
            'mi_tarificador_precio_tubo_DS160',
            'Precio del tubo para DS160 (€)',
            'mi_tarificador_precio_tubo_DS160_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );

        add_settings_field(
            'mi_tarificador_precio_tubo_DS290',
            'Precio del tubo para DS290 (€)',
            'mi_tarificador_precio_tubo_DS290_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );

        add_settings_field(
            'mi_tarificador_precio_manoObra_kitIluminacion',
            'Precio de mano de obra por montaje del kit de iluminación natural (€)',
            'mi_tarificador_precio_manoObra_kitIluminacion_callback',
            'mi_tarificador',
            'mi_tarificador_general_section'
        );
    
    }
    add_action('admin_init', 'mi_tarificador_register_settings');
      
    function mi_tarificador_webhook_url_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="text" id="mi_tarificador_webhook_url" name="mi_tarificador_options[mi_tarificador_webhook_url]" value="' . esc_attr($options['mi_tarificador_webhook_url']) . '">';
    }

    function mi_tarificador_precio_fachada_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_precio_fachada" name="mi_tarificador_options[mi_tarificador_precio_fachada]" value="' . esc_attr($options['mi_tarificador_precio_fachada']) . '">';
    }

    function mi_tarificador_precio_minimo_ruidos_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_precio_minimo_ruidos" name="mi_tarificador_options[mi_tarificador_precio_minimo_ruidos]" value="' . esc_attr($options['mi_tarificador_precio_minimo_ruidos']) . '">';
    }

    function mi_tarificador_precio_metros_ruidos_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_precio_metros_ruidos" name="mi_tarificador_options[mi_tarificador_precio_metros_ruidos]" value="' . esc_attr($options['mi_tarificador_precio_metros_ruidos']) . '">';
    }

    function mi_tarificador_precio_forjado_hasta130_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_precio_forjado_hasta130" name="mi_tarificador_options[mi_tarificador_precio_forjado_hasta130]" value="' . esc_attr($options['mi_tarificador_precio_forjado_hasta130']) . '">';
    }

    function mi_tarificador_precio_forjado_desde130_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_precio_forjado_desde130" name="mi_tarificador_options[mi_tarificador_precio_forjado_desde130]" value="' . esc_attr($options['mi_tarificador_precio_forjado_desde130']) . '">';
    }

    function mi_tarificador_precio_falsosTechos_hasta60_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_precio_falsosTechos_hasta60" name="mi_tarificador_options[mi_tarificador_precio_falsosTechos_hasta60]" value="' . esc_attr($options['mi_tarificador_precio_falsosTechos_hasta60']) . '">';
    }

    function mi_tarificador_precio_falsosTechos_desde60_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_precio_falsosTechos_desde60" name="mi_tarificador_options[mi_tarificador_precio_falsosTechos_desde60]" value="' . esc_attr($options['mi_tarificador_precio_falsosTechos_desde60']) . '">';
    }

    function mi_tarificador_precio_general_hasta20_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_precio_general_hasta20" name="mi_tarificador_options[mi_tarificador_precio_general_hasta20]" value="' . esc_attr($options['mi_tarificador_precio_general_hasta20']) . '">';
    }

    function mi_tarificador_precio_general_desde20hasta50_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_precio_general_desde20hasta50" name="mi_tarificador_options[mi_tarificador_precio_general_desde20hasta50]" value="' . esc_attr($options['mi_tarificador_precio_general_desde20hasta50']) . '">';
    }

    function mi_tarificador_precio_general_desde50hasta100_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_precio_general_desde50hasta100" name="mi_tarificador_options[mi_tarificador_precio_general_desde50hasta100]" value="' . esc_attr($options['mi_tarificador_precio_general_desde50hasta100']) . '">';
    }

    function mi_tarificador_precio_general_desde100_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_precio_general_desde100" name="mi_tarificador_options[mi_tarificador_precio_general_desde100]" value="' . esc_attr($options['mi_tarificador_precio_general_desde100']) . '">';
    }

    function mi_tarificador_potenciador_lanaRoca_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_potenciador_lanaRoca" name="mi_tarificador_options[mi_tarificador_potenciador_lanaRoca]" value="' . esc_attr($options['mi_tarificador_potenciador_lanaRoca']) . '">';
    }

    function mi_tarificador_potenciador_lanaMineral_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_potenciador_lanaMineral" name="mi_tarificador_options[mi_tarificador_potenciador_lanaMineral]" value="' . esc_attr($options['mi_tarificador_potenciador_lanaMineral']) . '">';
    }

    function mi_tarificador_precio_kitIluminacion_DS160_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_precio_kitIluminacion_DS160" name="mi_tarificador_options[mi_tarificador_precio_kitIluminacion_DS160]" value="' . esc_attr($options['mi_tarificador_precio_kitIluminacion_DS160']) . '">';
    }

    function mi_tarificador_precio_kitIluminacion_DS290_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_precio_kitIluminacion_DS290" name="mi_tarificador_options[mi_tarificador_precio_kitIluminacion_DS290]" value="' . esc_attr($options['mi_tarificador_precio_kitIluminacion_DS290']) . '">';
    }

    function mi_tarificador_precio_tubo_DS160_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_precio_tubo_DS160" name="mi_tarificador_options[mi_tarificador_precio_tubo_DS160]" value="' . esc_attr($options['mi_tarificador_precio_tubo_DS160']) . '">';
    }

    function mi_tarificador_precio_tubo_DS290_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_precio_tubo_DS290" name="mi_tarificador_options[mi_tarificador_precio_tubo_DS290]" value="' . esc_attr($options['mi_tarificador_precio_tubo_DS290']) . '">';
    }

    function mi_tarificador_precio_manoObra_kitIluminacion_callback() {
        $options = get_option('mi_tarificador_options');
        echo '<input type="number" step="any" id="mi_tarificador_precio_manoObra_kitIluminacion" name="mi_tarificador_options[mi_tarificador_precio_manoObra_kitIluminacion]" value="' . esc_attr($options['mi_tarificador_precio_manoObra_kitIluminacion']) . '">';
    }

    // LÓGICA PRINCIPAL DEL PLUGIN
    function mi_tarificador_func() {

    // Declaramos las variables GET como globales
    global $tipo_usuario;
    global $action;
    global $id_holded;
    
    // Recuperamos las variables puestas en la página de configuración del plugin
    $options = get_option('mi_tarificador_options');
    $webhook_url = $options['mi_tarificador_webhook_url'];
    $precio_metros_fachada = $options['mi_tarificador_precio_fachada'];
    $precio_minimo_ruidos = $options['mi_tarificador_precio_minimo_ruidos'];
    $precio_metros_ruidos = $options['mi_tarificador_precio_metros_ruidos'];
    $precio_forjado_hasta130 = $options['mi_tarificador_precio_forjado_hasta130'];
    $precio_forjado_desde130 = $options['mi_tarificador_precio_forjado_desde130'];
    $precio_falsosTechos_hasta60 = $options['mi_tarificador_precio_falsosTechos_hasta60'];
    $precio_falsosTechos_desde60 = $options['mi_tarificador_precio_falsosTechos_desde60'];
    $precio_general_hasta20 = $options['mi_tarificador_precio_general_hasta20'];
    $precio_general_desde20hasta50 = $options['mi_tarificador_precio_general_desde20hasta50'];
    $precio_general_desde50hasta100 = $options['mi_tarificador_precio_general_desde50hasta100'];
    $precio_general_desde100 = $options['mi_tarificador_precio_general_desde100'];
    $potenciador_lanaRoca = $options['mi_tarificador_potenciador_lanaRoca'];
    $potenciador_lanaMineral = $options['mi_tarificador_potenciador_lanaMineral'];
    $precio_kitIluminacion_DS160 = $options['mi_tarificador_precio_kitIluminacion_DS160'];
    $precio_kitIluminacion_DS290 = $options['mi_tarificador_precio_kitIluminacion_DS290'];
    $precio_tubo_DS160 = $options['mi_tarificador_precio_tubo_DS160'];
    $precio_tubo_DS290 = $options['mi_tarificador_precio_tubo_DS290'];
    $precio_manoObra_kitIluminacion = $options['mi_tarificador_precio_manoObra_kitIluminacion'];
    
    wp_enqueue_style('mi-tarificador-styles', plugin_dir_url(__FILE__) . 'css/styles.css');
    wp_enqueue_script('mi-tarificador-script', plugin_dir_url(__FILE__) . 'js/scripts.js', array('jquery'), '1.1.5', true);
    wp_localize_script('mi-tarificador-script', 'miTarificadorData', array('webhookURL' => $webhook_url, 'precioMetrosFachada' => $precio_metros_fachada, 'precioMinimoRuidos' => $precio_minimo_ruidos, 'precioMetrosRuidos' => $precio_metros_ruidos, 'manoObraForjadoHasta130' => $precio_forjado_hasta130, 'manoObraForjadoDesde130' => $precio_forjado_desde130, 'manoObraFalsosTechosHasta60' => $precio_falsosTechos_hasta60, 'manoObraFalsosTechosDesde60' => $precio_falsosTechos_desde60, 'manoObraHasta20' => $precio_general_hasta20, 'manoObraDesde20Hasta50' => $precio_general_desde20hasta50, 'manoObraDesde50Hasta100' => $precio_general_desde50hasta100, 'manoObraDesde100' => $precio_general_desde100, 'potenciadorLanaRoca' => $potenciador_lanaRoca, 'potenciadorLanaMineral' => $potenciador_lanaMineral, 'precioKitDS160' => $precio_kitIluminacion_DS160, 'precioKitDS290' => $precio_kitIluminacion_DS290, 'precioTuboDS160' => $precio_tubo_DS160, 'precioTuboDS290' => $precio_tubo_DS290, 'precioManoObraKitIluminacion' => $precio_manoObra_kitIluminacion));
    ob_start();
    ?>
    <div id="mi-tarificador">
        <span id="id_holded"><?php echo $id_holded; ?></span>
        <!-- BREADCRUMB -->
        <div id="breadcrumb" class="breadcrumb">
            <div class="breadcrumb-item active" id="breadcrumb-step-queOcurre"><span class="paso">Paso</span><span>1</span></div>
            <div class="breadcrumb-item" id="breadcrumb-step-comoOcurre"><span class="paso">Paso</span><span>2</span></div>
            <div class="breadcrumb-item" id="breadcrumb-step-quienEres"><span class="paso">Paso</span><span>3</span></div>
        </div>
        
        <!-- PANTALLA DE PROBLEMAS -->
        <div id="pantalla-1" class="pantalla pantalla-activa">
            <?php 
                if($tipo_usuario == "instalador" && $action == "recalcular") {
                    ?>
                    <div id="pantalla-1_instalador_titulo">
                        <p>MODO DE INSTALADOR</p>
                        <p>Utiliza el tarificador para ingresar los nuevos datos y generar el presupuesto corregido. Se actualizará el presupuesto.</p>
                    </div>
                    <?php
                }
            ?>
            <h2>¿Qué problema tienes?</h2>
            <h4>Selecciona uno de los problemas siguientes para comenzar a ayudarte</h4>
            <div id="problemas-cont" class="wrapper">
                <div class="container" title="Necesito iluminación natural">
                    <div class="inner-container">
                        <div>
                            <input type="radio" id="iluminacion-natural" name="problema" class="problema" value="iluminacion_natural">
                            <label for="iluminacion-natural"><img src="<?php echo plugin_dir_url(__FILE__); ?>images/iconos_tarificador/iluminacion_natural.svg" alt="Necesito iluminación natural"></label>
                        </div>
                        <div>
                            <span>Necesito iluminación</span>
                        </div>
                    </div>
                </div>
                <div class="container" title="Paso frío o calor">
                    <div class="inner-container">
                        <div>
                            <input type="radio" id="paso-frio-calor" name="problema" class="problema" value="paso_frio_calor">
                            <label for="paso-frio-calor"><img src="<?php echo plugin_dir_url(__FILE__); ?>images/iconos_tarificador/frio_calor.svg" alt="Paso frío o calor"></label>
                        </div>
                        <div>
                            <span>Paso frío o calor</span>
                        </div>
                    </div>
                </div>
                <div class="container" title="Tengo condensación">
                    <div class="inner-container">
                        <div>
                            <input type="radio" id="condensacion" name="problema" class="problema" value="condensacion">
                            <label for="condensacion"><img src="<?php echo plugin_dir_url(__FILE__); ?>images/iconos_tarificador/condensacion.svg" alt="Tengo condensación"></label>
                        </div>
                        <div>
                            <span>Tengo condensación</span>
                        </div>
                    </div>
                </div>
                <div class="container" title="Tengo filtraciones">
                    <div class="inner-container">
                        <div>
                            <input type="radio" id="filtraciones" name="problema" class="problema" value="filtraciones">
                            <label for="filtraciones"><img src="<?php echo plugin_dir_url(__FILE__); ?>images/iconos_tarificador/filtraciones.svg" alt="Tengo filtraciones"></label>
                        </div>
                        <div>
                            Tengo filtraciones
                        </div>
                    </div>
                </div>
                <div class="container" title="Me sube humedad">
                    <div class="inner-container">
                        <div>
                            <input type="radio" id="humedad" name="problema" class="problema" value="humedad">
                            <label for="humedad"><img src="<?php echo plugin_dir_url(__FILE__); ?>images/iconos_tarificador/humedad.svg" alt="Me sube humedad"></label>
                        </div>
                        <div>
                            Me sube humedad
                        </div>
                    </div>
                </div>
                <div class="container" title="Escucho muchos ruidos">
                    <div class="inner-container">
                        <div>
                            <input type="radio" id="ruidos" name="problema" class="problema" value="ruidos">
                            <label for="ruidos"><img src="<?php echo plugin_dir_url(__FILE__); ?>images/iconos_tarificador/ruidos.svg" alt="Escucho muchos ruidos"></label>
                        </div>
                        <div>
                            Escucho muchos ruidos
                        </div>
                    </div>
                </div>
            </div>
            <div id="pantalla1-botoneria" class="botoneria-derecha">
                <?php
                    if($tipo_usuario != "instalador" && $action != "recalcular") {
                        ?>
                            <div id="instalador-directo-cont" class="boton_cont">
                                <button id="btn-instalador-directo" class="boton"><img src="<?php echo plugin_dir_url(__FILE__); ?>images/tecnico.svg" alt="Técnico"><span><span>Solicitar ayuda</span><br><span>Quiero que un instalador venga a mi casa</span></span></button>
                            </div>
                        <?php
                    }
                ?>
                <div class="boton_cont">
                    <button id="siguiente-1" class="boton" title="Siguiente">Siguiente <span class="dashicons dashicons-arrow-right-alt2"></span></button>
                </div>
                <div id="fondoPopover" class="fondoPopover"></div>
                <div id="popover-instalador-directo" class="popover">
                    <p>Servicio incluido</p>
                    <p>Se generará un presupuesto de 0€ que se le enviará al correo electrónico. Tras <strong>aceptarlo</strong>, podrá seleccionar una cita con un técnico.</p>
                    <button id="btn-instalador-directo-confirm" class="boton">Solicitar cita con un técnico para valorar el problema</button>
                </div>
            </div>
        </div>

        <!-- PANTALLA PARA LA ILUMINACIÓN NATURAL -->
        <div id="pantalla-1-2" class="pantalla">
            <div id="siNaveIndustrial-cont">
                <h2>¿Es una nave industrial?</h2>
                <div class="boton_cont botones_siNaveIndustrial">
                    <button id="si-naveIndustrial" class="boton si_naveIndustrial"><span class="dashicons dashicons-yes"></span> SÍ</button>
                    <button id="no-naveIndustrial" class="boton no_naveIndustrial"><span class="dashicons dashicons-no"></span> NO</button>
                </div>
            </div>
            <div id="habitaciones-1-2-cont">
                <h2>Añade las habitaciones a iluminar</h2>
                <div>
                    <div id="datos-habitacion-1-2-cont">
                        <div class="habitacion_input_cont"><label for="nombre-habitacion-1-2">Nombre de la habitación</label> <input type="text" name="nombre_habitacion-1-2" id="nombre-habitacion-1-2" class="nombre_habitacion-1-2"></div>
                        <div class="habitacion_input_cont"><label for="metros-habitacion-1-2">M<sup>2</sup> de la habitación</label> <input type="number" name="metros_habitacion-1-2" id="metros-habitacion-1-2" class="metros_habitacion-1-2" min="0"></div>
                        <div class="habitacion_input_cont"><label for="distancia-cubierta-1-2">Distancia hasta la cubierta (metros)</label> <input type="number" name="distancia_cubierta-1-2" id="distancia-cubierta-1-2" class="distancia_cubierta-1-2" min="1" max="100"></div>
                    </div>
                    <div class="boton_cont">
                        <button id="limpiar-tabla-1-2" class='boton'>Limpiar tabla</button>
                        <button id="nueva-habitacion-1-2" class="boton">Añadir habitación +</button>
                    </div>
                </div>
                <div>
                    <table id="tabla-pantalla-1-2" class="tabla">
                        <thead>
                            <tr>
                                <th>Nombre de la habitación</th>
                                <th>M<sup>2</sup> de la habitación</th>
                                <th>Distancia hasta la cubierta (metros)</th>
                                <th>Kit de iluminación</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="botoneria-extremos">
                <button id="atras-1-2" class="boton" title="Atrás"><span class="dashicons dashicons-arrow-left-alt2"></span> Volver</button>
                <button id="siguiente-1-2" class="boton" title="Siguiente">Siguiente <span class="dashicons dashicons-arrow-right-alt2"></span></button>
            </div>

            <!-- MODAL PARA EL BOTÓN DE ILUMINACIÓN DE NAVES INDUSTRIALES -->
            <div id="modal-naveIndustrial" class="modal">
                <div class="modal-content">
                    <span id="closeModalBtnNavesIndustriales" class="close">&times;</span>
                    <div id="modal-body">
                        <div id="modal-texto">
                            <p>Eccoaisla no presta servicio para la iluminación de naves industriales</p>
                            <p>Para este tipo de presupuesto ponte en contacto con nosotros</p>
                            <p><a href='https://eccoaisla.com/contacto'>Más información</a></p>
                        </div>
                        <div id="modal-img">
                            <img src="<?php echo plugin_dir_url(__FILE__); ?>images/imagotipo-eccoaisla.svg" alt="Eccoaisla">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="pantalla-1-3" class="pantalla">
            <div id="tipo-ruidos-cont">
                <h2>¿Qué tipo de ruidos escuchas?</h2>
                <div class="boton_cont botones_tipoRuidos">
                    <button id="ruido-impacto" class="boton ruidoImpacto">RUIDOS POR IMPACTO (golpes, pisadas...)</button>
                    <button id="ruido-aereo" class="boton ruidoAereo">RUIDOS AÉREOS (conversaciones, música, televisores...)</button>
                </div>
            </div>
            <div id="localizacion-ruidos-cont">
                <h2>¿Qué necesitas aislar?</h2>
                <div class="boton-cont botones_localizacionRuidos">
                    <button id="ruidos-soloPared" class="boton ruidos_soloPared">PAREDES</button>
                    <button id="ruidos-soloTecho" class="boton ruidos_soloTecho">TECHO</button>
                </div>
            </div>
            <div id="ruidos-paredes-cont">
                <h2>¿En cuántas paredes tienes el problema?</h2>
                
                <div>
                    <div id="datos-paredesRuidos-cont">
                        <div class="paredRuido_input_cont"><label for="nombre-paredRuido">Nombre de la pared</label> <input type="text" name="nombre_paredRuido" id="nombre-paredRuido" class="nombre_paredRuido" placeholder="Ej: Pared 1 del salón"></div>
                        <div class="paredRuido_input_cont"><label for="metrosAlto-paredRuido">Alto de la pared (metros)</label> <input type="number" name="metrosAlto_paredRuido" id="metrosAlto-paredRuido" class="metrosAlto_paredRuido" min="0"></div>
                        <div class="paredRuido_input_cont"><label for="metrosAncho-paredRuido">Ancho de la pared (metros)</label> <input type="number" name="metrosAncho_paredRuido" id="metrosAncho-paredRuido" class="metrosAncho_paredRuido" min="0"></div>
                    </div>
                    <div class="boton_cont">
                        <button id="limpiar-tabla-1-3" class='boton'>Limpiar tabla</button>
                        <button id="nueva-pared-1-3" class="boton">Añadir pared +</button>
                    </div>
                </div>
                <div>
                    <table id="tabla-pantalla-1-3" class="tabla">
                        <thead>
                            <tr>
                                <th>Nombre de la pared</th>
                                <th>Alto de la pared</th>
                                <th>Ancho de la pared</th>
                                <th>M<sup>2</sup> de la pared</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        </tbody>
                    </table>
                </div>

                <div class='banner_tip banner_flex'>
                    <div>
                        <span class="negrita">Perderás 7 cm de grosor en las paredes</span>
                        <span>
                            Todos los enchufes, rodapiés y molduras serán recolocados en su nueva ubicación. Este presupuesto <span class="negrita">NO INCLUYE</span> estos materiales, que deberán ser proporcionados por el cliente.
                        </span>
                    </div>
                </div>
                <!--<div id="tip-paredesRuido-cont">
                    <div id="tip-paredesRuido-body">
                        <div id="tip-paredesRuido-texto">
                            <p>Perderás 7 cm de grosor en las paredes</p>
                            <p>Todos los enchufes, rodapiés y molduras serán recolocados en su nueva ubicación. Este presupuesto <span style="font-weight: bolder;">NO INCLUYE</span> estos materiales, que deberán ser proporcionados por el cliente.</p>
                        </div>
                        <div id="tip-paredesRuido-img">
                            <img src="<?php echo plugin_dir_url(__FILE__); ?>images/lupa.png" alt="Lupa">
                        </div>
                    </div>
                </div>-->
            </div>
            <div id="ruidos-techo-cont">
                <h2>¿En cuántas habitaciones tienes el problema?</h2>
                <div id="datos-techoRuido-cont">
                    <div>
                        <label for="numHabitaciones-ruidos">Número de habitaciones afectadas</label>
                        <input type="number" name="numHabitaciones_ruidos" id="numHabitaciones-ruidos" min="1" required>
                    </div>
                    <div>
                        <label for="metrosHabitaciones-ruidos">M<sup>2</sup> totales de habitaciones afectadas</label>
                        <input type="number" name="metrosHabitaciones_ruidos" id="metrosHabitaciones-ruidos" min="1" required>
                    </div>
                </div>
                <div class='banner_tip banner_flex'>
                    <div>
                        <span class="negrita">Perderás 12 cm de grosor en el techo</span>
                        <span>
                            Todos los enchufes, rodapiés y molduras serán recolocados en su nueva ubicación. Este presupuesto <span class="negrita">NO INCLUYE</span> estos materiales, que deberán ser proporcionados por el cliente.
                        </span>
                    </div>
                </div>
                <!--<div id="tip-techoRuido-cont">
                    <div id="tip-techoRuido-body">
                        <div id="tip-techoRuido-texto">
                            <p>Perderás 12 cm de grosor en el techo</p>
                            <p>Todos los enchufes, rodapiés y molduras serán recolocados en su nueva ubicación. Este presupuesto <span style="font-weight: bolder;">NO INCLUYE</span> estos materiales, que deberán ser proporcionados por el cliente.</p>
                        </div>
                        <div id="tip-techoRuido-img">
                            <img src="<?php echo plugin_dir_url(__FILE__); ?>images/lupa.png" alt="Lupa">
                        </div>
                    </div>
                </div>-->
            </div>
            <div class="botoneria-extremos">
                <button id="atras-1-3" class="boton" title="Atrás"><span class="dashicons dashicons-arrow-left-alt2"></span> Volver</button>
                <button id="siguiente-1-3" class="boton" title="Siguiente">Siguiente <span class="dashicons dashicons-arrow-right-alt2"></span></button>
            </div>

            <!-- MODAL PARA EL BOTÓN DE RUIDO DE IMPACTOS -->
            <div id="modal-ruidosImpacto" class="modal">
                <div class="modal-content">
                    <span id="closeModalBtn" class="close">&times;</span>
                    <div id="modal-body">
                        <div id="modal-texto">
                            <p>Eccoaisla no presta servicio para aislar ruidos por impacto</p>
                            <p>Estos solo pueden solucionarse en la propia construcción de la vivienda.</p>
                            <p><a href='https://eccoaisla.com/contacto'>Más información</a></p>
                        </div>
                        <div id="modal-img">
                            <img src="<?php echo plugin_dir_url(__FILE__); ?>images/imagotipo-eccoaisla.svg" alt="Eccoaisla">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- PANTALLA DE TIPOS DE VIVIENDA -->
        <div id="pantalla-2" class="pantalla">
            <h2>¿Qué tipo de vivienda tiene?</h2>
            <h4>Selecciona tu tipo de vivienda</h4>
            <div id="tipoVivienda-cont" class="wrapper">
                <div class="container" title="Vivienda independiente">
                    <div class="inner-container">
                        <div>
                            <input type="radio" id="vivienda-independiente" name="tipo_vivienda" class="tipo-vivienda" value="vivienda_independiente">
                            <label for="vivienda-independiente"><img src="<?php echo plugin_dir_url(__FILE__); ?>images/iconos_tarificador/vivienda.svg" alt="Vivienda independiente"></label>
                        </div>
                        <div>
                            Vivienda independiente
                        </div>
                    </div>
                    
                </div>
                <div class="container ultima_planta_cont" title="Última planta de un edificio">
                    <div class="inner-container">
                        <div>
                            <input type="radio" id="ultima-planta" name="tipo_vivienda" class="tipo-vivienda" value="ultima_planta">
                            <label for="ultima-planta"><img src="<?php echo plugin_dir_url(__FILE__); ?>images/iconos_tarificador/edificio_buhardilla.svg" alt="Última planta de un edificio"></label>
                        </div>
                        <div>
                            Última planta de un edificio
                        </div>
                    </div>
                </div>
                <div class="container" title="Vivienda en un edificio">
                    <div class="inner-container">
                        <div>
                            <input type="radio" id="vivienda-edificio" name="tipo_vivienda" class="tipo-vivienda" value="vivienda_edificio">
                            <label for="vivienda-edificio"><img src="<?php echo plugin_dir_url(__FILE__); ?>images/iconos_tarificador/entreplanta.svg" alt="Vivienda en un edificio"></label>
                        </div>
                        <div>
                            Vivienda en un edificio
                        </div>
                    </div>
                </div>
                <div class="container" title="Local comercial">
                    <div class="inner-container">
                        <div>
                            <input type="radio" id="local" name="tipo_vivienda" class="tipo-vivienda" value="local">
                            <label for="local"><img src="<?php echo plugin_dir_url(__FILE__); ?>images/iconos_tarificador/local.svg" alt="Local comercial"></label>
                        </div>
                        <div>
                            Local comercial
                        </div>
                    </div>
                </div>
                <div class="container" title="Garaje">
                    <div class="inner-container">
                        <div>
                            <input type="radio" id="garaje" name="tipo_vivienda" class="tipo-vivienda" value="garaje">
                            <label for="garaje"><img src="<?php echo plugin_dir_url(__FILE__); ?>images/iconos_tarificador/garaje.svg" alt="Garaje"></label>
                        </div>
                        <div>
                            Garaje
                        </div>
                    </div>
                </div>
                <div class="container" title="Nave industrial">
                    <div class="inner-container">
                        <div>
                            <input type="radio" id="nave-industrial" name="tipo_vivienda" class="tipo-vivienda" value="nave_industrial">
                            <label for="nave-industrial"><img src="<?php echo plugin_dir_url(__FILE__); ?>images/iconos_tarificador/nave.svg" alt="Nave industrial"></label>
                        </div>
                        <div>
                            Nave industrial
                        </div>
                    </div>
                </div>
            </div>
            <div class="botoneria-extremos">
                <button id="atras-2" class="boton" title="Atrás"><span class="dashicons dashicons-arrow-left-alt2"></span> Volver</button>
                <button id="siguiente-2" class="boton" title="Siguiente">Siguiente <span class="dashicons dashicons-arrow-right-alt2"></span></button>
            </div>
        </div>

        <!-- PANTALLA DE SELECCIÓN PARA AISLAR PAREDES, CUBIERTA O LAS DOS COSAS -->
        <div id="pantalla-3" class="pantalla">
            <div id="paredes-cubiertas-cont">
                <!--<div id='tip-descuentoParedesCubierta-cont'>
                    <div id='tip-descuentoParedesCubierta-body'>
                        <div id="tip-descuentoParedesCubierta-img">
                            <img src="<?php echo plugin_dir_url(__FILE__); ?>images/descuento.png" alt="Descuento por pronto pago">
                        </div>
                        <div id='tip-descuentoParedesCubierta-texto'>
                            <p>¡Aprovéchalo!</p>
                            <div>
                                Ahora si decides aislar <span>paredes y cubiertas</span> tendrás un descuento de un <span>6%</span> en tu presupuesto
                            </div>
                        </div>
                    </div>
                </div>-->
                <!--<div class='banner_tip'><span class="dashicons dashicons-star-empty"></span> <span class="negrita">¡Aprovéchalo!</span> &#8212; Ahora si decides aislar <span class="negrita">paredes y cubiertas</span> tendrás un descuento de un <span class="negrita">6%</span> en tu presupuesto</div>-->

                <div class='banner_tip'>
                    <div><img src="<?php echo plugin_dir_url(__FILE__); ?>images/imagotipo-eccoaisla.svg" alt="ECCOAISLA"></div>
                    <div><span class="negrita">¡Aprovéchalo!</span></div>
                    <div><span>Ahora si decides aislar <span class="negrita">paredes y cubiertas</span> tendrás un descuento de un <span class="negrita">6%</span> en tu presupuesto</div>
                </div>
                <h2>¿Qué quieres aislar?</h2>
                <div class="boton_cont botones_siParedCubierta">
                    <button id="si-pared" class="boton si_pared">SOLO LAS PAREDES</button>
                    <button id="si-cubierta" class="boton si_cubierta">SOLO LA CUBIERTA</button>
                    <button id="si-paredCubierta" class="boton si_paredCubierta">PAREDES Y CUBIERTA</button>
                </div>
            </div>
            <div id="tipo-cubierta-cont">
                <div>
                    <h2>¿Cuántos metros cuadrados de tejado tiene la vivienda?</h2>
                    <p><input type="number" name="metros_tejado" id="metros-tejado" min="1" required placeholder="m&sup2;"></p>
                </div>
                <div>
                    <h2>¿Cómo es tu cubierta?</h2>
                    <div id="cubiertas-cont" class="wrapper">
                        <div class="container" title="Cubierta tradicional">
                            <div class="inner-container">
                                <div>
                                    <input type="radio" id="cubierta-tradicional" name="tipo_cubierta" class="tipo_cubierta" value="cubierta_tradicional">
                                    <label for="cubierta-tradicional"><img src="<?php echo plugin_dir_url(__FILE__); ?>images/iconos_tarificador/cubierta_tradicional.svg" alt="Cubierta tradicional"></label>
                                </div>
                                <div>
                                    Cubierta tradicional
                                </div>
                            </div>
                            
                        </div>
                        <div class="container" title="Cubierta plana">
                            <div class="inner-container">
                                <div>
                                    <input type="radio" id="cubierta-plana" name="tipo_cubierta" class="tipo_cubierta" value="cubierta_plana">
                                    <label for="cubierta-plana"><img src="<?php echo plugin_dir_url(__FILE__); ?>images/iconos_tarificador/cubierta_plana.svg" alt="Cubierta plana"></label>
                                </div>
                                <div>
                                    Cubierta plana
                                </div>
                            </div>
                        </div>
                        <div class="container" title="Cubierta abuhardillada">
                            <div class="inner-container">
                                <div>
                                    <input type="radio" id="cubierta-abuhardillada" name="tipo_cubierta" class="tipo_cubierta" value="cubierta_abuhardillada">
                                    <label for="cubierta-abuhardillada"><img src="<?php echo plugin_dir_url(__FILE__); ?>images/iconos_tarificador/cubierta_abuhardillada.svg" alt="Cubierta abuhardillada"></label>
                                </div>
                                <div>
                                    Cubierta abuhardillada
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class='banner_tip banner_flex'>
                    <div>
                        <span class="negrita">Las cubiertas planas y las abuhardilladas pueden tener falso techo, pero... ¿cómo lo sé?</span>
                        <span>
                            ¡Muy fácil! Para saber si tienes falso techo debajo de tu cubierta plana o abuhardillada simplemente <span class="negrita">golpea tu techo</span>. ¿Suena hueco? Entonces es probable que tengas falsos techo. Por el contrario, si es un material macizo (como el hormigón) <a href='https://eccoaisla.com/contacto-oficina'>contacte con nuestras oficinas</a>.
                        </span>
                    </div>
                </div>
                <!--<div id='tip-falsoTecho-cont'>
                    <div id='tip-falsoTecho-body'>
                        <div id='tip-falsoTecho-texto'>
                            <p>Las cubiertas planas y las abuhardilladas pueden tener falso techo, pero... ¿cómo lo sé?</p>
                            <p>¡Muy fácil! Para saber si tienes falso techo debajo de tu cubierta plana o abuhardillada simplemente <span>golpea tu techo</span>. ¿Suena hueco? Entonces es probable que tengas falsos techo.</p>
                            <p>Por el contrario, si es un material macizo (como el hormigón)</p>
                            <p><a href='https://eccoaisla.com/contacto-oficina'>contacte con nuestras oficinas</a>.</p>
                        </div>
                        <div id="tip-techoRuido-img">
                            <img src="<?php echo plugin_dir_url(__FILE__); ?>images/oido.png" alt="Oído">
                        </div>
                    </div>
                </div>-->        
            </div>
            <div class="botoneria-extremos">
                <button id="atras-3" class="boton" title="Atrás"><span class="dashicons dashicons-arrow-left-alt2"></span> Volver</button>
                <button id="siguiente-3" class="boton" title="Siguiente">Siguiente <span class="dashicons dashicons-arrow-right-alt2"></span></button>
            </div>
        </div>

        <!-- PANTALLA PARA OBTENER INFORMACIÓN DE LAS PAREDES -->
        <div id="pantalla-4" class="pantalla">
            <h2>Añade las paredes que dan al exterior</h2>
            <div>
                <div id="datos-paredes-cont">
                    <div class="pared_input_cont"><label for="nombre-pared">Nombre de la pared</label> <input type="text" name="nombre_pared" id="nombre-pared" class="nombre_pared" placeholder="Ej: Pared 1 del salón"></div>
                    <div class="pared_input_cont"><label for="metrosAlto-pared">Alto de la pared (metros)</label> <input type="number" name="metrosAlto_pared" id="metrosAlto-pared" class="metrosAlto_pared" min="0"></div>
                    <div class="pared_input_cont"><label for="metrosAncho-pared">Ancho de la pared (metros)</label> <input type="number" name="metrosAncho_pared" id="metrosAncho-pared" class="metrosAncho_pared" min="0"></div>
                </div>
                <div class="boton_cont">
                    <button id="limpiar-tabla" class='boton'>Limpiar tabla</button>
                    <button id="nueva-pared-4" class="boton">Añadir pared +</button>
                </div>
            </div>
            <div>
                <table id="tabla-pantalla-4" class="tabla">
                    <thead>
                        <tr>
                            <th>Nombre de la pared</th>
                            <th>Alto de la pared</th>
                            <th>Ancho de la pared</th>
                            <th>M<sup>2</sup> de la pared</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                    </tbody>
                </table>
            </div>
            <div>

            </div>

            <div class="botoneria-extremos">
                <button id="atras-4" class="boton" title="Atrás"><span class="dashicons dashicons-arrow-left-alt2"></span> Volver</button>
                <button id="siguiente-4" class="boton" title="Siguiente">Siguiente <span class="dashicons dashicons-arrow-right-alt2"></span></button>
            </div>
        </div>

        <!-- PANTALLA DE OBTENCIÓN DE DATOS PERSONALES -->
        <div id="pantalla-5" class="pantalla">
            <!--<div id='tip-descuentoProntoPago-cont'>
                <div id='tip-descuentoProntoPago-body'>
                    <div id="tip-descuentoProntoPago-img">
                        <img src="<?php echo plugin_dir_url(__FILE__); ?>images/descuento.png" alt="Descuento por pronto pago">
                    </div>
                    <div id='tip-descuentoProntoPago-texto'>
                        <p>¡Oferta verde!</p>
                        <div>
                            <span>3%</span> de descuento si aceptas el presupuesto en menos de <span>5 días</span>
                        </div>
                    </div>
                </div>
            </div>-->

            <div class='banner_tip'>
                <div><img src="<?php echo plugin_dir_url(__FILE__); ?>images/imagotipo-eccoaisla.svg" alt="ECCOAISLA"></div>
                <div><span class="negrita">¡Oferta Verde!</span></div>
                <div><span>Llévate un <span class="negrita">3%</span> de descuento si aceptas el presupuesto en menos de <span class="negrita">5 días</span></div>
                <!--<span class="dashicons dashicons-star-empty"></span> <span class="negrita">¡Oferta verde!</span> &#8212; Llévate un <span class="negrita">3%</span> de descuento si aceptas el presupuesto en menos de <span class="negrita">5 días</span>-->
            </div>
            <h2>Cuéntanos sobre ti</h2>
            <?php
                if($tipo_usuario == "instalador" && $action == "recalcular") {
                    ?>
                    <div id="pantalla-5_instalador_subtitulo">
                        <p>MODO DE INSTALADOR</p>
                        <p>Los datos del cliente no se pueden modificar, pero puedes corregir si la vivienda es de alquiler o no y añadir cualquier nota de interés que pueda ser útil.</p>
                    </div>
                    <?php
                }

                if($tipo_usuario != "instalador" && $action != "recalcular") {
                    ?>
                    <div class="inputs_datosPersonales_cont">
                        <div><label for="nombre_presupuesto">Nombre:</label> <input type="text" id="nombre_presupuesto" name="nombre_presupuesto" maxlength="100" required></div>
                        <div><label for="apellidos_presupuesto">Apellidos:</label> <input type="text" id="apellidos_presupuesto" name="apellidos_presupuesto" maxlength="100" required></div>
                    </div>
                    <div class="inputs_datosPersonales_cont">
                        <div><label for="email_presupuesto">Correo electrónico:</label> <input type="email" id="email_presupuesto" name="email_presupuesto" maxlength="100" required></div>
                        <div><label for="telefono_presupuesto">Teléfono:</label> <input type="tel" id="telefono_presupuesto" name="telefono_presupuesto" required></div>
                    </div>
                    <div class="inputs_datosPersonales_cont">
                        <div><label for="direccion_presupuesto">Dirección:</label> <input type="text" name="direccion_presupuesto" id="direccion_presupuesto" maxlength="100" placeholder="Calle, 0" required></div>
                        <div><label for="ciudad_presupuesto">Ciudad:</label> <input type="text" name="ciudad_presupuesto" id="ciudad_presupuesto" maxlenth="100" required></div>
                    </div>
                    <?php
                }
            ?>
                <div class="inputs_datosPersonales_cont">
                    <div><label for="provincia_presupuesto">Zona/provincia:</label> 
                        <select required name="provincia_presupuesto" id="provincia_presupuesto">
                            <option value="">Elige tu zona</option>
                            <option value="Extremadura/Salamanca/Zamora">Extremadura/Salamanca/Zamora</option>
                            <option value="La Coruña/A Coruña" disabled>La Coruña/A Coruña</option>
                            <option value="Álava/Araba" disabled>Álava/Araba</option>
                            <option value="Albacete" disabled>Albacete</option>
                            <option value="Alicante/Alacant" disabled>Alicante/Alacant</option>
                            <option value="Almería" disabled>Almería</option>
                            <option value="Asturias" disabled>Asturias</option>
                            <option value="Ávila">Ávila</option>
                            <option value="Barcelona">Barcelona</option>
                            <option value="Bilbao">Bilbao</option>
                            <option value="Burgos" disabled>Burgos</option>
                            <option value="Cádiz" disabled>Cádiz</option>
                            <option value="Cantabria" disabled>Cantabria</option>
                            <option value="Castellón/Castelló" disabled>Castellón/Castelló</option>
                            <option value="Ciudad Real" disabled>Ciudad Real</option>
                            <option value="Córdoba" disabled>Córdoba</option>
                            <option value="Cuenca" disabled>Cuenca</option>
                            <option value="Gerona/Girona" disabled>Gerona/Girona</option>
                            <option value="Granada" disabled>Granada</option>
                            <option value="Guadalajara" disabled>Guadalajara</option>
                            <option value="Gipuzkoa" disabled>Gipuzkoa</option>
                            <option value="Huelva" disabled>Huelva</option>
                            <option value="Huesca" disabled>Huesca</option>
                            <option value="Islas Baleares/Illes Balears" disabled>Islas Baleares/Illes Balears</option>
                            <option value="Jaén" disabled>Jaén</option>
                            <option value="La Rioja" disabled>La Rioja</option>
                            <option value="Las Palmas" disabled>Las Palmas</option>
                            <option value="León" disabled>León</option>
                            <option value="Lérida/Lleida">Lérida/Lleida</option>
                            <option value="Lugo" disabled>Lugo</option>
                            <option value="Madrid">Madrid</option>
                            <option value="Madrid Central">Madrid Central</option>
                            <option value="Málaga" disabled>Málaga</option>
                            <option value="Murcia" disabled>Murcia</option>
                            <option value="Navarra" disabled>Navarra</option>
                            <option value="Ourense" disabled>Ourense</option>
                            <option value="Palencia" disabled>Palencia</option>
                            <option value="Pontevedra" disabled>Pontevedra</option>
                            <option value="Santa Cruz de Tenerife" disabled>Santa Cruz de Tenerife</option>
                            <option value="Segovia">Segovia</option>
                            <option value="Sevilla" disabled>Sevilla</option>
                            <option value="Soria">Soria</option>
                            <option value="Tarragona">Tarragona</option>
                            <option value="Teruel" disabled>Teruel</option>
                            <option value="Toledo">Toledo</option>
                            <option value="Valencia/València" disabled>Valencia/València</option>
                            <option value="Valladolid">Valladolid</option>
                            <option value="Zaragoza" disabled>Zaragoza</option>
                        </select>
                    </div>
                </div>
                <div class="inputs_datosPersonales_cont textarea-cont">
                    <div><label for="notas_presupuesto">Notas adicionales</label><textarea name="notas_presupuesto" id="notas_presupuesto" cols="30" rows="10"></textarea></div>
                </div>
                <div class="inputs_datosPersonales_cont ultimo-datosPersonales-cont">
                    <div>
                        <label for="alquiler_presupuesto">¿La vivienda se encuentra en régimen de alquiler?</label>
                        <div class="checkbox-wrapper-6">
                            <input class="tgl tgl-light" id="alquiler_presupuesto" name="alquiler_presupuesto" type="checkbox" required/>
                            <label class="tgl-btn" for="alquiler_presupuesto">
                        </div>
                    </div>
                    <div>
                        <label for="empresa_presupuesto">Soy empresa</label>
                        <div class="checkbox-wrapper-6">
                            <input class="tgl tgl-light" id="empresa_presupuesto" name="empresa_presupuesto" type="checkbox" required/>
                            <label class="tgl-btn" for="empresa_presupuesto">
                        </div>
                    </div>
                    <div>
                        <label for="acceso_presupuesto">¿Tiene el acceso a su vivienda restricciones de entrada y circulación según el tipo de vehículo?</label>
                        <div class="checkbox-wrapper-6">
                            <input class="tgl tgl-light" id="acceso_presupuesto" name="acceso_presupuesto" type="checkbox" required/>
                            <label class="tgl-btn" for="acceso_presupuesto">
                        </div>
                    </div>
                </div>


            <div class="boton_cont">
                <button id="enviar" class="boton" title="Enviar presupuesto"><span class="dashicons dashicons-upload"></span> Enviar presupuesto</button>
            </div>
        </div>
        
        <!-- PANTALLA DE RESUMEN DEL PRESUPUESTO -->
        <!--<div id="pantalla-6" class="pantalla">
            <h2>Resumen del presupuesto</h2>
            <div id="resumen_cont">
                <div id="resumen_nombre"><span class="resumen_nombre">Nombre</span><span class="resumen_resultado"></span></div>
                <div id="resumen_apellidos"><span class="resumen_nombre">Apellidos</span><span class="resumen_resultado"></span></div>
                <div id="resumen_email"><span class="resumen_nombre">Correo electrónico</span><span class="resumen_resultado"></span></div>
                <div id="resumen_telefono"><span class="resumen_nombre">Teléfono</span><span class="resumen_resultado"></span></div>
                <div id="resumen_direccion"><span class="resumen_nombre">Dirección</span><span class="resumen_resultado"></span></div>
                <div id="resumen_ciudad"><span class="resumen_nombre">Ciudad</span><span class="resumen_resultado"></span></div>
                <div id="resumen_provincia"><span class="resumen_nombre">Provincia</span><span class="resumen_resultado"></span></div>
                <div id="resumen_problema"><span class="resumen_nombre">Problema</span><span class="resumen_resultado"></span></div>
                <div id="resumen_presupuestoTotal"><span class="resumen_nombre">Presupuesto total</span><span class="resumen_resultado"></span></div>
            </div>
            <div class="boton_cont">
                <button id="enviar" class="boton">Aceptar y enviar</button>
            </div>
        </div>-->
    </div>
    <?php
    return ob_get_clean();
}

// CREACIÓN DEL SHORTCODE
add_shortcode('mi-tarificador', 'mi_tarificador_func');