<?php
    // Si uninstall.php no es llamado por WordPress, salir
    if (!defined('WP_UNINSTALL_PLUGIN')) {
        exit();
    }

    // Eliminar las opciones guardadas en la base de datos
    delete_option('mi_tarificador_options');
?>