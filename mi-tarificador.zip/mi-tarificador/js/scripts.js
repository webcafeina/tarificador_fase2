jQuery(document).ready(function($) {

    // RECUPERAMOS LAS VARIABLES DEL PANEL DE CONFIGURACIÓN PASADAS DEL PHP
    const webhookURL = miTarificadorData.webhookURL;
    const precioMetrosFachada = miTarificadorData.precioMetrosFachada;
    const precioMinimoRuidos = miTarificadorData.precioMinimoRuidos;
    const precioMetrosRuidos = miTarificadorData.precioMetrosRuidos;
    const manoObraForjadoHasta130 = miTarificadorData.manoObraForjadoHasta130;
    const manoObraForjadoDesde130 = miTarificadorData.manoObraForjadoDesde130;
    const manoObraFalsosTechosHasta60 = miTarificadorData.manoObraFalsosTechosHasta60;
    const manoObraFalsosTechosDesde60 = miTarificadorData.manoObraFalsosTechosDesde60;
    const manoObraHasta20 = miTarificadorData.manoObraHasta20;
    const manoObraDesde20Hasta50 = miTarificadorData.manoObraDesde20Hasta50;
    const manoObraDesde50Hasta100 = miTarificadorData.manoObraDesde50Hasta100;
    const manoObraDesde100 = miTarificadorData.manoObraDesde100;
    const potenciadorLanaRoca = miTarificadorData.potenciadorLanaRoca;
    const potenciadorLanaMineral = miTarificadorData.potenciadorLanaMineral;
    const precioKitDS160 = miTarificadorData.precioKitDS160;
    const precioKitDS290 = miTarificadorData.precioKitDS290;
    const precioTuboDS160 = miTarificadorData.precioTuboDS160;
    const precioTuboDS290 = miTarificadorData.precioTuboDS290;
    const manoObraKitIluminacion = miTarificadorData.precioManoObraKitIluminacion;

    // OBJETO DONDE GUARDAREMOS LOS DIFERENTES DATOS
    var respuestas = {
        es_nuevo_instalador: false,
        es_instalador: false,
        es_presupuesto_corregido: false,
        id_holded: '',
        problema: '',
        tipo_vivienda: '',
        necesita_iluminacion: false,
        datos_habitaciones_iluminacion: {
            nombre_habitacion: [],
            metros_habitacion: [],
            distancia_cubierta: [],
            kit_iluminacion: [],
            precio_kit: [],
            subtotal_habitacion: []
        },
        datos_paredes_aislar: {
            nombre_pared: [],
            metros_alto_pared: [],
            metros_ancho_pared: [],
            espesor_pared: [],
            metros_pared: [],
            metros_cubicos_pared: []
        },
        datos_paredes_aislarRuido: {
            nombre_pared: [],
            metros_alto_pared: [],
            metros_ancho_pared: [],
            metros_pared: [],
        },
        espesor_paredes: 0,
        es_alquiler: false,
        es_empresa: false,
        restriccion_acceso: false,
        metros_cuadrados: 0,
        metros_cubicos: 0,
        metros_cuadrados_tejado: 0,
        toda_vivienda: false,
        tiene_pared: false,
        tiene_cubierta: false,
        tiene_cubierta_pared: false,
        tipo_cubierta: '',
        tiene_ruidos: false,
        localizacion_ruidos: '',
        paredes_ruido: 0,
        metros_paredes_ruido: 0,
        habitaciones_ruido: 0,
        metros_habitaciones_ruido: 0,
        nombre: '',
        apellidos: '',
        email: '',
        telefono: '',
        direccion: '',
        ciudad: '',
        provincia: '',
        presupuesto_forjado: 0,
        presupuesto_falsosTechos: 0,
        presupuesto_general: 0,
        presupuesto: 0,
        notas_presupuesto: 'NO',
        necesita_ceramica: false,
        necesita_rollers: false,
        cantidad_ceramica: 0,
        sobrecoste_ceramica: 0,
        cantidad_rollers: 0,
        sobrecoste_rollers: 0,
        descuento_aceptacion: false
    };

    // VARIABLE SUMATORIA DE SUBTOTALES DE LA ILUMINACIÓN NATURAL
    var sumatorioSubtotal_1_2 = 0;

    // VARIABLE SUMATORIA DE METROS DE PAREDES A AISLAR
    var sumatorioMetrosParedes_4 = 0;
    var sumatorioMetrosParedes_1_3 = 0;

    // VARIABLE SUMATORIA DE METROS CÚBICOS DE PAREDES A AISLAR
    var sumatorioMetrosCubicosParedes_4 = 0;

    // FUNCIÓN PARA CAMBIAR DE PANTALLAS
    function actualizarPantalla(pantalla) {
        $('.pantalla').removeClass('pantalla-activa');
        $(pantalla).addClass('pantalla-activa');
    }

    // FUNCIÓN PARA NORMALIZAR VARIABLES ANTES DE PASARLAS AL WEBHOOK
    function normalizarVariables() {
        switch(respuestas.problema) {
            case 'cambiar_ventanas':
                respuestas.problema = 'Necesito cambiar mis ventanas';
            break;
            case 'paso_frio_calor':
                respuestas.problema = 'Paso frío o calor';
            break;
            case 'condensacion':
                respuestas.problema = 'Tengo condensación';
            break;
            case 'filtraciones':
                respuestas.problema = 'Tengo filtraciones';
            break;
            case 'humedad':
                respuestas.problema = 'Me sube humedad por la pared';
            break;
            case 'ruidos':
                respuestas.problema = 'Escucho muchos ruidos';
            break;
            case 'iluminacion_natural':
                respuestas.problema = 'Necesito iluminación natural';
            break;
        }

        switch(respuestas.tipo_vivienda) {
            case 'vivienda_independiente':
                respuestas.tipo_vivienda = 'Vivienda independiente';
            break;
            case 'ultima_planta':
                respuestas.tipo_vivienda = 'Última planta de un edificio';
            break;
            case 'vivienda_edificio':
                respuestas.tipo_vivienda = 'Vivienda en un edificio';
            break;
            case 'nave_industrial':
                respuestas.tipo_vivienda = 'Nave industrial';
            break;
            case 'local':
                respuestas.tipo_vivienda = 'Local comercial';
            break;
            case 'garaje':
                respuestas.tipo_vivienda = 'Garaje';
            break;
        }

        switch(respuestas.tipo_cubierta) {
            case 'cubierta_tradicional':
                respuestas.tipo_cubierta = 'Cubierta tradicional';
            break;
            case 'cubierta_plana':
                respuestas.tipo_cubierta = 'Cubierta plana';
            break;
            case 'cubierta_abuhardillada':
                respuestas.tipo_cubierta = 'Cubierta abuhardillada';
            break;
        }

        switch(respuestas.es_alquiler) {
            case false:
                respuestas.es_alquiler = 'LA VIVIENDA NO SE ENCUENTRA EN SITUACIÓN DE ALQUILER';
            break;

            case true:
                respuestas.es_alquiler = 'LA VIVIENDA SE ENCUENTRA EN SITUACIÓN DE ALQUILER';
        }

        switch(respuestas.restriccion_acceso) {
            case true:
                respuestas.restriccion_acceso = 'EL ACCESO A LA VIVIENDA CUENTA CON RESTRICCIONES SEGÚN EL TIPO DE VEHÍCULO';
            break;

            case false:
                respuestas.restriccion_acceso = 'EL ACCESO A LA VIVIENDA NO CUENTA CON RESTRICCIONES SEGÚN EL TIPO DE VEHÍCULO';
        }
    }

    // LÓGICA DE LOS BOTONES ATRÁS Y SIGUIENTE DE PANTALLA 1-2
    function checkButtonWidth() {
        if ($(window).width() < 590) {
            if ($('#siguiente-1-2').css('display') == 'none') {
                $('#atras-1-2').css('cssText', 'width: 100% !important;');
            } else {
                $('#atras-1-2').css('cssText', 'width: 50% !important;');
            }
        } else {
            $('#atras-1-2').css('width', '');
        }

        if ($(window).width() < 590) {
            if ($('#siguiente-1-3').css('display') == 'none') {
                $('#atras-1-3').css('cssText', 'width: 100% !important;');
            } else {
                $('#atras-1-3').css('cssText', 'width: 50% !important;');
            }
        } else {
            $('#atras-1-3').css('width', '');
        }

        if ($(window).width() < 590) {
            if ($('#siguiente-3').css('display') == 'none') {
                $('#atras-3').css('cssText', 'width: 100% !important;');
            } else {
                $('#atras-3').css('cssText', 'width: 50% !important;');
            }
        } else {
            $('#atras-3').css('width', '');
        }
    }
    
    checkButtonWidth();
    $(window).resize(checkButtonWidth);


    var observerConfig = { attributes: true, attributeFilter: ['style'] };
    $('#siguiente-1-2, #siguiente-1-3, #siguiente-3').each(function() {
        var observer = new MutationObserver(checkButtonWidth);
        observer.observe(this, observerConfig);
    });

    // LÓGICA DEL POPOVER DE PANTALLA 1
    var botonPopover = $("#btn-instalador-directo");
    var botonConfirmacion = $("#btn-instalador-directo-confirm");

    botonPopover.on("click", function(e) {
        $("#popover-instalador-directo, #fondoPopover").css("display", "block");
    });

    botonConfirmacion.on("click", function(e) {
        $("#popover-instalador-directo, #fondoPopover").css("display", "none");
        respuestas.problema = "Necesito que el instalador venga a auditar el problema";
        setActiveBreadcrumb('quienEres');
        actualizarPantalla('#pantalla-5');
    });

    $("#fondoPopover").on("click", function() {
        $("#popover-instalador-directo, #fondoPopover").css("display", "none");
    });

    $("#popover-instalador-directo").on("click", function(e) {
        e.stopPropagation();
    });

    // LÓGICA DEL POPOVER DE PANTALLA 4
    var botonPopover4 = $("#btn-popover-metros-paredes");

    botonPopover4.on("click", function(e) {
        $("#popover-metros-paredes, #fondoPopover-4").css("display", "block");
    });

    $("#fondoPopover-4").on("click", function() {
        $("#popover-metros-paredes, #fondoPopover-4").css("display", "none");
    });

    $("#popover-metros-paredes").on("click", function(e) {
        e.stopPropagation();
    });
    
    // FUNCIÓN PARA ELEGIR EL BREADCRUMB ACTIVO
    function setActiveBreadcrumb(step) {
        const breadcrumbItems = document.querySelectorAll('.breadcrumb-item');
        breadcrumbItems.forEach((item) => {
            item.classList.remove('active');
        });

        const currentBreadcrumb = document.querySelector(`#breadcrumb-step-${step}`);
        currentBreadcrumb.classList.add('active');
    }

    // FUNCIÓN PARA CHEQUEAR SI LA CIUDAD COINCIDE CON LA PROVINCIA
    async function chequearCiudadProvincia(ciudad, provincia) {
        const url = `https://nominatim.openstreetmap.org/search?city=${encodeURIComponent(ciudad)}&county=${encodeURIComponent(provincia)}&country=Spain&format=json&addressdetails=1&limit=1`;
        const respuesta = await fetch(url);
        const data = await respuesta.json();

        if(data && data.length > 0) {
            const ciudadMatch = data[0].address.city === ciudad || data[0].address.town === ciudad;
            const provinciaMatch = data[0].address.county === provincia || data[0].address.state === provincia || data[0].address.state_district === provincia;

            return true;
        }

        return false;
    }

    // FUNCIÓN PARA LOS DIFERENTES CÁLCULOS Y OBTENER UN PRESUPUESTO
    function calcularPresupuesto() {

        // SI SE NECESITA QUE EL INSTALADOR VAYA DIRECTAMENTE PARA AUDITAR EL PROBLEMA
        if(respuestas.problema == 'Necesito que el instalador venga a auditar el problema') {
            normalizarVariables();

            // Envía la información al webhook de Zapier
            var url = webhookURL;

            $.ajax({
                type: 'POST',
                url: url,
                data: JSON.stringify(respuestas),
                //contentType: 'application/json',
                success: function() {
                    window.location.href = 'https://eccoaisla.com/presupuesto-enviado';
                    /* console.log(respuestas); */
                },
                error: function() {
                    // Muestra un mensaje de error o realiza alguna acción en caso de error
                    console.error('Error al enviar los datos: ', error);
                }
            });
        }

        // SI EL PROBLEMA ES ILUMINACIÓN NATURAL
        if(respuestas.problema == 'iluminacion_natural' && respuestas.necesita_iluminacion == true) {
            normalizarVariables();
            /* $('#resumen_nombre .resumen_resultado').html(respuestas.nombre);
            $('#resumen_apellidos .resumen_resultado').html(respuestas.apellidos);
            $('#resumen_email .resumen_resultado').html(respuestas.email);
            $('#resumen_telefono .resumen_resultado').html(respuestas.telefono);
            $('#resumen_direccion .resumen_resultado').html(respuestas.direccion);
            $('#resumen_ciudad .resumen_resultado').html(respuestas.ciudad);
            $('#resumen_provincia .resumen_resultado').html(respuestas.provincia);
            $('#resumen_problema .resumen_resultado').html(respuestas.problema);
            $('#resumen_problema').after("<div id='resumen_habitaciones'><span class='resumen_nombre'>Habitaciones</span><table id='tabla-resumen' class='tabla'><thead><tr><th>Nombre de la habitación</th><th>M<sup>2</sup> de la habitación</th><th>Distancia hasta la cubierta (metros)</th><th>Kit de iluminación</th><th>Subtotal</th></tr></thead><tbody></tbody></table></div>");
            for(let i=0; i<respuestas.datos_habitaciones_iluminacion.nombre_habitacion.length; i++) {
                $('#resumen_habitaciones #tabla-resumen tbody').append("<tr><td>"+respuestas.datos_habitaciones_iluminacion.nombre_habitacion[i]+"</td><td>"+respuestas.datos_habitaciones_iluminacion.metros_habitacion[i]+"</td><td>"+respuestas.datos_habitaciones_iluminacion.distancia_cubierta[i]+"</td><td>"+respuestas.datos_habitaciones_iluminacion.kit_iluminacion[i]+"</td><td>"+respuestas.datos_habitaciones_iluminacion.subtotal_habitacion[i]+"</td></tr>");
            }
            $('#resumen_presupuestoTotal .resumen_resultado').html(respuestas.presupuesto); */

            // Envía la información al webhook de Zapier
            var url = webhookURL;

            $.ajax({
                type: 'POST',
                url: url,
                data: JSON.stringify(respuestas),
                //contentType: 'application/json',
                success: function() {
                    window.location.href = 'https://eccoaisla.com/presupuesto-enviado';
                    /* console.log(respuestas); */
                },
                error: function() {
                    // Muestra un mensaje de error o realiza alguna acción en caso de error
                    console.error('Error al enviar los datos: ', error);
                }
            });
        }

        // SI EL PROBLEMA ES QUE SE PASA FRÍO O CALOR, CONDENSACIÓN O HUMEDAD
        if(respuestas.problema == 'paso_frio_calor' || respuestas.problema == 'condensacion' || respuestas.problema == 'humedad') {
            if(respuestas.tipo_vivienda == 'vivienda_independiente' || respuestas.tipo_vivienda == 'ultima_planta') {
                if(respuestas.tiene_cubierta == true && respuestas.tiene_cubierta_pared == false && respuestas.tiene_pared == false) {
                    if(respuestas.tipo_cubierta == 'cubierta_plana' || respuestas.tipo_cubierta == 'cubierta_abuhardillada') {

                        // AL SER CUBIERTA TRADICIONAL CALCULAMOS FALSOS TECHOS
                        if(respuestas.metros_cuadrados_tejado < 60) {
                            var manoObraFalsosTechos = manoObraFalsosTechosHasta60;
                        } else {
                            var manoObraFalsosTechos = manoObraFalsosTechosDesde60;
                        }

                        if(respuestas.provincia == "Barcelona") {

                            var presupuestoFalsosTechos = parseFloat((((respuestas.metros_cuadrados_tejado*0.10) * 50) + parseFloat(manoObraFalsosTechos)) * parseFloat(1.10)).toFixed(2);
        
                        } else if(respuestas.provincia == "Madrid" || respuestas.provincia == "Madrid Central") {
        
                            var presupuestoFalsosTechos = parseFloat((((respuestas.metros_cuadrados_tejado*0.10) * 50) + parseFloat(manoObraFalsosTechos)) * parseFloat(1.10)).toFixed(2);
        
                        } else {
                            var presupuestoFalsosTechos = parseFloat((((respuestas.metros_cuadrados_tejado*0.10) * 50) + parseFloat(manoObraFalsosTechos)) * parseFloat(potenciadorLanaRoca)).toFixed(2);
                        }

                        respuestas.presupuesto = parseFloat(presupuestoFalsosTechos);

                    } else if(respuestas.tipo_cubierta == 'cubierta_tradicional') {

                        // AL SER CUBIERTA PLANA O ABUHARDILLADA CALCULAMOS FORJADO
                        if(respuestas.metros_cuadrados_tejado < 130) {
                            var manoObraForjado = manoObraForjadoHasta130;
                        } else {
                            var manoObraForjado = manoObraForjadoDesde130;
                        }

                        if(respuestas.provincia == "Barcelona") {

                            var presupuestoForjado = parseFloat((((respuestas.metros_cuadrados_tejado*0.24) * 30) + parseFloat(manoObraForjado)) * parseFloat(1.10)).toFixed(2);
        
                        } else if(respuestas.provincia == "Madrid" || respuestas.provincia == "Madrid Central") {
        
                            var presupuestoForjado = parseFloat((((respuestas.metros_cuadrados_tejado*0.24) * 30) + parseFloat(manoObraForjado)) * parseFloat(1.10)).toFixed(2);
        
                        } else {
                            var presupuestoForjado = parseFloat((((respuestas.metros_cuadrados_tejado*0.24) * 30) + parseFloat(manoObraForjado)) * parseFloat(potenciadorLanaMineral)).toFixed(2);
                        }

                        respuestas.presupuesto = parseFloat(presupuestoForjado);

                    }

                    // MOSTRAMOS LOS DATOS EN LOS CAMPOS DEL RESUMEN
                    normalizarVariables();

                    /* $('#resumen_nombre .resumen_resultado').html(respuestas.nombre);
                    $('#resumen_apellidos .resumen_resultado').html(respuestas.apellidos);
                    $('#resumen_email .resumen_resultado').html(respuestas.email);
                    $('#resumen_telefono .resumen_resultado').html(respuestas.telefono);
                    $('#resumen_direccion .resumen_resultado').html(respuestas.direccion);
                    $('#resumen_ciudad .resumen_resultado').html(respuestas.ciudad);
                    $('#resumen_provincia .resumen_resultado').html(respuestas.provincia);
                    $('#resumen_problema .resumen_resultado').html(respuestas.problema);
                    $('#resumen_problema').after("<div id='resumen_soloCubierta'><span class='resumen_nombre'>¿Aislar cubiertas y paredes?</span><span class='resumen_resultado'>Solo la cubierta</span></div><div id='resumen_tipoCubierta'><span class='resumen_nombre'>Tipo de cubierta</span><span class='resumen_resultado'>"+respuestas.tipo_cubierta+"</span></div>");
                    $('#resumen_presupuestoTotal .resumen_resultado').html(respuestas.presupuesto);
                    if(respuestas.tipo_cubierta == 'Cubierta tradicional') {
                        $("#resumen_presupuestoTotal").after("<div id='tip-lanaMineral-cont'><div id='tip-lanaMineral-caption'><span>Uso de lana mineral</span></div><div id='tip-lanaMineral-body'><div id='tip-lanaMineral-texto'><p>Este presupuesto está calculado con <span>lana mineral</span>.</p><p>En algunos casos se puede usar <span>celulosa</span> como material aislante, suponiendo aproximadamente un 35% de ahorro.</p><p>Para saber si su proyecto puede usar celulosa, póngase en contacto con <a href='https://eccoaisla.webcafeina.com/contacto-oficina'>nuestras oficinas</a>.</p></div></div></div>");
                    } */

                    // Envía la información al webhook de Zapier
                    var url = webhookURL;

                    $.ajax({
                        type: 'POST',
                        url: url,
                        data: JSON.stringify(respuestas),
                        //contentType: 'application/json',
                        success: function() {
                            window.location.href = 'https://eccoaisla.com/presupuesto-enviado';
                            /* console.log(respuestas); */
                        },
                        error: function() {
                            // Muestra un mensaje de error o realiza alguna acción en caso de error.
                            console.error('Error al enviar los datos: ', error);
                        }
                    });

                } else if(respuestas.tiene_cubierta_pared == true && respuestas.tiene_cubierta == false && respuestas.tiene_pared == false) {

                    if(respuestas.tipo_cubierta == 'cubierta_plana' || respuestas.tipo_cubierta == 'cubierta_abuhardillada') {

                        // AL SER CUBIERTA TRADICIONAL CALCULAMOS FALSOS TECHOS
                        if(respuestas.metros_cuadrados_tejado < 60) {
                            var manoObraFalsosTechos = manoObraFalsosTechosHasta60;
                        } else {
                            var manoObraFalsosTechos = manoObraFalsosTechosDesde60;
                        }

                        if(respuestas.provincia == "Barcelona") {

                            var presupuestoFalsosTechos = parseFloat((((respuestas.metros_cuadrados_tejado*0.10) * 50) + parseFloat(manoObraFalsosTechos)) * parseFloat(1.10)).toFixed(2);
        
                        } else if(respuestas.provincia == "Madrid" || respuestas.provincia == "Madrid Central") {
        
                            var presupuestoFalsosTechos = parseFloat((((respuestas.metros_cuadrados_tejado*0.10) * 50) + parseFloat(manoObraFalsosTechos)) * parseFloat(1.10)).toFixed(2);
        
                        } else {
                            var presupuestoFalsosTechos = parseFloat((((respuestas.metros_cuadrados_tejado*0.10) * 50) + parseFloat(manoObraFalsosTechos)) * parseFloat(potenciadorLanaRoca)).toFixed(2);
                        }

                        respuestas.presupuesto_falsosTechos = parseFloat(presupuestoFalsosTechos);

                    } else if(respuestas.tipo_cubierta == 'cubierta_tradicional') {

                        // AL SER CUBIERTA PLANA O ABUHARDILLADA CALCULAMOS FORJADO
                        if(respuestas.metros_cuadrados_tejado < 130) {
                            var manoObraForjado = manoObraForjadoHasta130;
                        } else {
                            var manoObraForjado = manoObraForjadoDesde130;
                        }

                        if(respuestas.provincia == "Barcelona") {

                            var presupuestoForjado = parseFloat((((respuestas.metros_cuadrados_tejado*0.24) * 30) + parseFloat(manoObraForjado)) * parseFloat(1.10)).toFixed(2);
        
                        } else if(respuestas.provincia == "Madrid" || respuestas.provincia == "Madrid Central") {
        
                            var presupuestoForjado = parseFloat((((respuestas.metros_cuadrados_tejado*0.24) * 30) + parseFloat(manoObraForjado)) * parseFloat(1.10)).toFixed(2);
        
                        } else {
                            var presupuestoForjado = parseFloat((((respuestas.metros_cuadrados_tejado*0.24) * 30) + parseFloat(manoObraForjado)) * parseFloat(potenciadorLanaMineral)).toFixed(2);
                        }

                        respuestas.presupuesto_forjado = parseFloat(presupuestoForjado);

                    }

                    // CALCULAMOS EL PRESUPUESTO DE PAREDES PARA SUMÁRSELO AL PRESUPUESTO DE FORJADO/FALSOS TECHOS
                    if(respuestas.metros_cuadrados < 20) {
                        var manoObraGeneral = manoObraHasta20;
                    } else if(respuestas.metros_cuadrados >= 20 && respuestas.metros_cuadrados < 50) {
                        var manoObraGeneral = manoObraDesde20Hasta50;
                    } else if(respuestas.metros_cuadrados >= 50 && respuestas.metros_cuadrados < 100) {
                        var manoObraGeneral = manoObraDesde50Hasta100;
                    } else {
                        var manoObraGeneral = manoObraDesde100;
                    }
                    
                    if(respuestas.provincia == "Barcelona") {

                        var presupuestoGeneral = parseFloat((((respuestas.metros_cuadrados*0.05) * 70) + parseFloat(manoObraGeneral)) * parseFloat(1.10)).toFixed(2);
    
                    } else if(respuestas.provincia == "Madrid" || respuestas.provincia == "Madrid Central") {
    
                        var presupuestoGeneral = parseFloat((((respuestas.metros_cuadrados*0.05) * 70) + parseFloat(manoObraGeneral)) * parseFloat(1.10)).toFixed(2);
    
                    } else {
                        var presupuestoGeneral = parseFloat((((respuestas.metros_cuadrados*0.05) * 70) + parseFloat(manoObraGeneral)) * parseFloat(potenciadorLanaRoca)).toFixed(2);
                    }

                    respuestas.presupuesto_general = parseFloat(presupuestoGeneral);

                    if(respuestas.tipo_cubierta == 'cubierta_plana' || respuestas.tipo_cubierta == 'cubierta_abuhardillada') {

                        respuestas.presupuesto = (parseFloat(presupuestoFalsosTechos) + parseFloat(presupuestoGeneral)).toFixed(2);

                    } else if(respuestas.tipo_cubierta == 'cubierta_tradicional') {

                        respuestas.presupuesto = (parseFloat(presupuestoForjado) + parseFloat(presupuestoGeneral)).toFixed(2);

                    }

                    // MOSTRAMOS LOS DATOS EN LOS CAMPOS DEL RESUMEN
                    normalizarVariables();

                    /* $('#resumen_nombre .resumen_resultado').html(respuestas.nombre);
                    $('#resumen_apellidos .resumen_resultado').html(respuestas.apellidos);
                    $('#resumen_email .resumen_resultado').html(respuestas.email);
                    $('#resumen_telefono .resumen_resultado').html(respuestas.telefono);
                    $('#resumen_direccion .resumen_resultado').html(respuestas.direccion);
                    $('#resumen_ciudad .resumen_resultado').html(respuestas.ciudad);
                    $('#resumen_provincia .resumen_resultado').html(respuestas.provincia);
                    $('#resumen_problema .resumen_resultado').html(respuestas.problema);
                    $('#resumen_problema').after("<div id='resumen_cubiertasParedes'><span class='resumen_nombre'>¿Aislar cubiertas y paredes?</span><span class='resumen_resultado'>Cubierta y paredes</span></div><div id='resumen_tipoCubierta'><span class='resumen_nombre'>Tipo de cubierta</span><span class='resumen_resultado'>"+respuestas.tipo_cubierta+"</span></div>");
                    if(respuestas.tipo_cubierta == 'Cubierta tradicional') {
                        $('#resumen_presupuestoTotal').before("<div id='resumen_partidaFalsosTechos'><span class='resumen_nombre'>Partida de forjado</span><span class='resumen_resultado'>"+respuestas.presupuesto_forjado+"</span></div><div id='resumen_presupuestoParedes'><span class='resumen_nombre'>Partida de paredes</span><span class='resumen_resultado'>"+respuestas.presupuesto_general+"</span></div><div id='resumen_metrosParedes'><span class='resumen_nombre'>M<sup>2</sup> de paredes a tratar</span><span class='resumen_resultado'>"+respuestas.metros_cuadrados+"</span></div>");
                        $("#resumen_presupuestoTotal").after("<div id='tip-lanaMineral-cont'><div id='tip-lanaMineral-caption'><span>Uso de lana mineral</span></div><div id='tip-lanaMineral-body'><div id='tip-lanaMineral-texto'><p>Este presupuesto está calculado con <span>lana mineral</span>.</p><p>En algunos casos se puede usar <span>celulosa</span> como material aislante.</p><p>Para saber si su proyecto puede usar celulosa, póngase en contacto con <a href='https://eccoaisla.webcafeina.com/contacto-oficina'>nuestras oficinas</a>.</p></div></div></div>");
                    } else if(respuestas.tipo_cubierta == 'Cubierta plana' || respuestas.tipo_cubierta == 'Cubierta abuhardillada') {
                        $('#resumen_presupuestoTotal').before("<div id='resumen_partidaForjado'><span class='resumen_nombre'>Partida de falsos techos</span><span class='resumen_resultado'>"+respuestas.presupuesto_falsosTechos+"</span></div><div id='resumen_presupuestoParedes'><span class='resumen_nombre'>Partida de paredes</span><span class='resumen_resultado'>"+respuestas.presupuesto_general+"</span></div><div id='resumen_metrosParedes'><span class='resumen_nombre'>M<sup>2</sup> de paredes a tratar</span><span class='resumen_resultado'>"+respuestas.metros_cuadrados+"</span></div>");
                        $("#resumen_presupuestoTotal").after("<div id='tip-falsoTecho-cont'><div id='tip-falsoTecho-caption'><span>¿Cómo se si tengo un falso techo?</span></div><div id='tip-falsoTecho-body'><div id='tip-falsoTecho-texto'><p>¡Muy fácil!</p><p>Para saber si tienes falso techo simplemente golpea tu techo.</p><p>¿Suena hueco? Entonces es probable que tengas falsos techo.</p><p>Por el contrario, si es un material macizo (como el hormigón), póngase en contacto con <a href='https://eccoaisla.webcafeina.com/contacto-oficina'>nuestras oficinas</a>.</p></div></div></div>");
                    }
                    $('#resumen_presupuestoTotal .resumen_resultado').html(respuestas.presupuesto); */

                    // Envía la información al webhook de Zapier
                    var url = webhookURL;

                    $.ajax({
                        type: 'POST',
                        url: url,
                        data: JSON.stringify(respuestas),
                        //contentType: 'application/json',
                        success: function() {
                            window.location.href = 'https://eccoaisla.com/presupuesto-enviado';
                            /* console.log(respuestas); */
                        },
                        error: function() {
                            // Muestra un mensaje de error o realiza alguna acción en caso de error
                            console.error('Error al enviar los datos: ', error);
                        }
                    });

                    
                } else if(respuestas.tiene_pared == true && respuestas.tiene_cubierta == false && respuestas.tiene_cubierta_pared == false) {
                    
                    // AL NO AISLAR CUBIERTA SOLO CALCULAMOS EL PRESUPUESTO DE PAREDES
                    if(respuestas.metros_cuadrados < 20) {
                        var manoObraGeneral = manoObraHasta20;
                    } else if(respuestas.metros_cuadrados >= 20 && respuestas.metros_cuadrados < 50) {
                        var manoObraGeneral = manoObraDesde20Hasta50;
                    } else if(respuestas.metros_cuadrados >= 50 && respuestas.metros_cuadrados < 100) {
                        var manoObraGeneral = manoObraDesde50Hasta100;
                    } else {
                        var manoObraGeneral = manoObraDesde100;
                    }

                    if(respuestas.provincia == "Barcelona") {

                        var presupuestoGeneral = parseFloat((((respuestas.metros_cuadrados*0.05) * 70) + parseFloat(manoObraGeneral)) * parseFloat(1.10)).toFixed(2);
    
                    } else if(respuestas.provincia == "Madrid" || respuestas.provincia == "Madrid Central") {
    
                        var presupuestoGeneral = parseFloat((((respuestas.metros_cuadrados*0.05) * 70) + parseFloat(manoObraGeneral)) * parseFloat(1.10)).toFixed(2);
    
                    } else {
                        var presupuestoGeneral = parseFloat((((respuestas.metros_cuadrados*0.05) * 70) + parseFloat(manoObraGeneral)) * parseFloat(potenciadorLanaRoca)).toFixed(2);
                    }

                    respuestas.presupuesto = parseFloat(presupuestoGeneral);

                    // MOSTRAMOS LOS DATOS EN LOS CAMPOS DEL RESUMEN
                    normalizarVariables();

                    /* $('#resumen_nombre .resumen_resultado').html(respuestas.nombre);
                    $('#resumen_apellidos .resumen_resultado').html(respuestas.apellidos);
                    $('#resumen_email .resumen_resultado').html(respuestas.email);
                    $('#resumen_telefono .resumen_resultado').html(respuestas.telefono);
                    $('#resumen_direccion .resumen_resultado').html(respuestas.direccion);
                    $('#resumen_ciudad .resumen_resultado').html(respuestas.ciudad);
                    $('#resumen_provincia .resumen_resultado').html(respuestas.provincia);
                    $('#resumen_problema .resumen_resultado').html(respuestas.problema);
                    $('#resumen_problema').after("<div id='resumen_soloParedes'><span class='resumen_nombre'>¿Aislar cubiertas y paredes?</span><span class='resumen_resultado'>Solo paredes</span></div></div>");
                    $('#resumen_presupuestoTotal').before("<div id='resumen_metrosParedes'><span class='resumen_nombre'>M<sup>2</sup> de paredes a tratar</span><span class='resumen_resultado'>"+respuestas.metros_cuadrados+"</span></div>");
                    $('#resumen_presupuestoTotal .resumen_resultado').html(respuestas.presupuesto); */

                    // Envía la información al webhook de Zapier
                    var url = webhookURL;

                    $.ajax({
                        type: 'POST',
                        url: url,
                        data: JSON.stringify(respuestas),
                        //contentType: 'application/json',
                        success: function() {
                            window.location.href = 'https://eccoaisla.com/presupuesto-enviado';
                            /* console.log(respuestas); */
                        },
                        error: function() {
                            // Muestra un mensaje de error o realiza alguna acción en caso de error.
                            console.error('Error al enviar los datos: ', error);
                        }
                    });

                }
            } else if(respuestas.tipo_vivienda == 'vivienda_edificio') {

                // AL SER ENTREPLANTA SOLO CALCULAMOS EL PRESUPUESTO DE PAREDES
                if(respuestas.metros_cuadrados < 20) {
                    var manoObraGeneral = manoObraHasta20;
                } else if(respuestas.metros_cuadrados >= 20 && respuestas.metros_cuadrados < 50) {
                    var manoObraGeneral = manoObraDesde20Hasta50;
                } else if(respuestas.metros_cuadrados >= 50 && respuestas.metros_cuadrados < 100) {
                    var manoObraGeneral = manoObraDesde50Hasta100;
                } else {
                    var manoObraGeneral = manoObraDesde100;
                }

                if(respuestas.provincia == "Barcelona") {

                    var presupuestoGeneral = parseFloat((((respuestas.metros_cuadrados*0.05) * 70) + parseFloat(manoObraGeneral)) * parseFloat(1.10)).toFixed(2);

                } else if(respuestas.provincia == "Madrid" || respuestas.provincia == "Madrid Central") {

                    var presupuestoGeneral = parseFloat((((respuestas.metros_cuadrados*0.05) * 70) + parseFloat(manoObraGeneral)) * parseFloat(1.10)).toFixed(2);

                } else {
                    var presupuestoGeneral = parseFloat((((respuestas.metros_cuadrados*0.05) * 70) + parseFloat(manoObraGeneral)) * parseFloat(potenciadorLanaRoca)).toFixed(2);
                }

                respuestas.presupuesto = parseFloat(presupuestoGeneral);

                // MOSTRAMOS LOS DATOS EN LOS CAMPOS DEL RESUMEN
                normalizarVariables();

                /* $('#resumen_nombre .resumen_resultado').html(respuestas.nombre);
                $('#resumen_apellidos .resumen_resultado').html(respuestas.apellidos);
                $('#resumen_email .resumen_resultado').html(respuestas.email);
                $('#resumen_telefono .resumen_resultado').html(respuestas.telefono);
                $('#resumen_direccion .resumen_resultado').html(respuestas.direccion);
                $('#resumen_ciudad .resumen_resultado').html(respuestas.ciudad);
                $('#resumen_provincia .resumen_resultado').html(respuestas.provincia);
                $('#resumen_problema .resumen_resultado').html(respuestas.problema);
                $('#resumen_problema').after("<div id='resumen_soloParedes'><span class='resumen_nombre'>¿Aislar cubiertas y paredes?</span><span class='resumen_resultado'>Solo paredes</span></div></div>");
                $('#resumen_presupuestoTotal').before("<div id='resumen_metrosParedes'><span class='resumen_nombre'>M<sup>2</sup> de paredes a tratar</span><span class='resumen_resultado'>"+respuestas.metros_cuadrados+"</span></div>");
                $('#resumen_presupuestoTotal .resumen_resultado').html(respuestas.presupuesto); */

                // Envía la información al webhook de Zapier
                var url = webhookURL;

                $.ajax({
                    type: 'POST',
                    url: url,
                    data: JSON.stringify(respuestas),
                    //contentType: 'application/json',
                    success: function() {
                        window.location.href = 'https://eccoaisla.com/presupuesto-enviado';
                        /* console.log(respuestas); */
                    },
                    error: function() {
                        // Muestra un mensaje de error o realiza alguna acción en caso de error
                        console.error('Error al enviar los datos: ', error);
                    }
                });

            }
        }

        // SI EL PROBLEMA SON LOS RUIDOS
        if(respuestas.problema == 'ruidos' && respuestas.tiene_ruidos == true) {

            // SI QUIERE AISLAR PAREDES
            if(respuestas.localizacion_ruidos == 'Paredes') {
                var presupuestoRuidos = (parseFloat(respuestas.metros_paredes_ruido) * parseFloat(precioMetrosRuidos)).toFixed(2);
                if(presupuestoRuidos < parseFloat(precioMinimoRuidos)) {
                    presupuestoRuidos = parseFloat(precioMinimoRuidos);
                }

                respuestas.presupuesto = parseFloat(presupuestoRuidos);

                // MOSTRAMOS LOS DATOS EN LOS CAMPOS DEL RESUMEN
                normalizarVariables();

                /* $('#resumen_nombre .resumen_resultado').html(respuestas.nombre);
                $('#resumen_apellidos .resumen_resultado').html(respuestas.apellidos);
                $('#resumen_email .resumen_resultado').html(respuestas.email);
                $('#resumen_telefono .resumen_resultado').html(respuestas.telefono);
                $('#resumen_direccion .resumen_resultado').html(respuestas.direccion);
                $('#resumen_ciudad .resumen_resultado').html(respuestas.ciudad);
                $('#resumen_provincia .resumen_resultado').html(respuestas.provincia);
                $('#resumen_problema .resumen_resultado').html(respuestas.problema);
                $('#resumen_problema').after("<div id='resumen_localizacionRuidos'><span class='resumen_nombre'>Elemento a aislar</span><span class='resumen_resultado'>"+respuestas.localizacion_ruidos+"</span></div><div id='resumen_numParedes_ruidos'><span class='resumen_nombre'>Paredes a aislar</span><span class='resumen_resultado'>"+respuestas.paredes_ruido+"</span></div><div id='resumen_metrosParedes_ruidos'><span class='resumen_nombre'>M<sup>2</sup> totales de paredes a aislar</span><span class='resumen_resultado'>"+respuestas.metros_paredes_ruido+"</span></div>");
                $('#resumen_presupuestoTotal .resumen_resultado').html(respuestas.presupuesto); */

                // Envía la información al webhook de Zapier
                var url = webhookURL;

                $.ajax({
                    type: 'POST',
                    url: url,
                    data: JSON.stringify(respuestas),
                    //contentType: 'application/json',
                    success: function() {
                        window.location.href = 'https://eccoaisla.com/presupuesto-enviado';
                        /* console.log(respuestas); */
                    },
                    error: function() {
                        // Muestra un mensaje de error o realiza alguna acción en caso de error
                        console.error('Error al enviar los datos: ', error);
                    }
                });

            // SI QUIERE AISLAR TECHOS
            } else if(respuestas.localizacion_ruidos == 'Techos') {
                var presupuestoRuidos = (parseFloat(respuestas.metros_habitaciones_ruido) * parseFloat(precioMetrosRuidos)).toFixed(2);
                if(presupuestoRuidos < parseFloat(precioMinimoRuidos)) {
                    presupuestoRuidos = parseFloat(precioMinimoRuidos);
                }

                respuestas.presupuesto = parseFloat(presupuestoRuidos);

                // MOSTRAMOS LOS DATOS EN LOS CAMPOS DEL RESUMEN
                normalizarVariables();

                /* $('#resumen_nombre .resumen_resultado').html(respuestas.nombre);
                $('#resumen_apellidos .resumen_resultado').html(respuestas.apellidos);
                $('#resumen_email .resumen_resultado').html(respuestas.email);
                $('#resumen_telefono .resumen_resultado').html(respuestas.telefono);
                $('#resumen_direccion .resumen_resultado').html(respuestas.direccion);
                $('#resumen_ciudad .resumen_resultado').html(respuestas.ciudad);
                $('#resumen_provincia .resumen_resultado').html(respuestas.provincia);
                $('#resumen_problema .resumen_resultado').html(respuestas.problema);
                $('#resumen_problema').after("<div id='resumen_localizacionRuidos'><span class='resumen_nombre'>Elemento a aislar</span><span class='resumen_resultado'>"+respuestas.localizacion_ruidos+"</span></div><div id='resumen_numHabitaciones_ruidos'><span class='resumen_nombre'>Habitaciones a aislar el techo</span><span class='resumen_resultado'>"+respuestas.habitaciones_ruido+"</span></div><div id='resumen_metrosHabitaciones_ruidos'><span class='resumen_nombre'>M<sup>2</sup> totales de habitaciones a aislar el techo</span><span class='resumen_resultado'>"+respuestas.metros_habitaciones_ruido+"</span></div>");
                $('#resumen_presupuestoTotal .resumen_resultado').html(respuestas.presupuesto); */

                // Envía la información al webhook de Zapier
                var url = webhookURL;

                $.ajax({
                    type: 'POST',
                    url: url,
                    data: JSON.stringify(respuestas),
                    //contentType: 'application/json',
                    success: function() {
                        window.location.href = 'https://eccoaisla.com/presupuesto-enviado';
                        /* console.log(respuestas); */
                    },
                    error: function() {
                        // Muestra un mensaje de error o realiza alguna acción en caso de error
                        console.error('Error al enviar los datos: ', error);
                    }
                });
            }
        }

    }

    // ASIGNAMOS EL PROBLEMA AL SELECCIONARLO
    $('.problema').on('change', function() {
        var valor = $(this).val();
        respuestas.problema = $(this).val();
    });

    // ASIGNAMOS EL TIPO DE VIVIENDA AL SELECCIONARLO
    $('.tipo-vivienda').on('change', function() {
        respuestas.tipo_vivienda = $(this).val();
    });

    // ASIGNAMOS EL TIPO DE CUBIERTA AL SELECCIONARLO
    $('.tipo_cubierta').on('change', function() {
        respuestas.tipo_cubierta = $(this).val();
    });

    // ASIGNAMOS SI LA VIVIENDA ES DE ALQUILER AL SELECCIONARLO
    $('#alquiler_presupuesto').on('change', function() {
        respuestas.es_alquiler = this.checked;
    });

    // ASIGNAMOS SI EL CLIENTE ES UNA EMPRESA AL SELECCIONARLO
    $('#empresa_presupuesto').on('change', function() {
        respuestas.es_empresa = this.checked;
    });

    // ASIGNAMOS SI LA VIVIENDA TIENE RESTRICCIONES DE ACCESO SEGÚN EL TIPO DE VEHÍCULO
    $('#acceso_presupuesto').on('change', function() {
        respuestas.restriccion_acceso = this.checked;
    });

    // AL PULSAR EL BOTÓN PARA QUE EL INSTALADOR VAYA A AUDITAR EL PROBLEMA DIRECTAMENTE
    /*$("#btn-instalador-directo").on('click', function() {
        respuestas.problema = "Necesito que el instalador venga a auditar el problema";
        setActiveBreadcrumb('quienEres');
        actualizarPantalla('#pantalla-5');
    });*/

    // AL PULSAR EL BOTÓN DE SIGUIENTE DE LA PANTALLA DE PROBLEMAS
    $('#siguiente-1').on('click', function() {
        if($("input[name='problema']:checked").length == 0) {
            if($('#pantalla-1 .alerta_validacion').length == 0) {
                $("#pantalla-1 h4").after("<div class='alerta_validacion'><span class='dashicons dashicons-warning'></span> Debes seleccionar una opción</div>");
            }
        } else {
            if($('.alerta_validacion').length > 0) {
                $('.alerta_validacion').remove();
            }

            if($('#pantalla-1_instalador_titulo').length > 0) {
                respuestas.es_instalador = true;
                respuestas.es_presupuesto_corregido = true;
                respuestas.id_holded = $("#id_holded").html();
            }

            // SI EL USUARIO TIENE FILTRACIONES ESCAPAMOS A UNA URL DE CONTACTO
            if(respuestas.problema == 'filtraciones') {
                window.location.href = 'https://eccoaisla.com/contacto';
            } else if(respuestas.problema == 'iluminacion_natural') {
                setActiveBreadcrumb('comoOcurre');
                actualizarPantalla('#pantalla-1-2');
            } else if(respuestas.problema == 'ruidos') {
                setActiveBreadcrumb('comoOcurre');
                actualizarPantalla('#pantalla-1-3');
            } else {
                setActiveBreadcrumb('comoOcurre');
                actualizarPantalla('#pantalla-2');
            }

            // SI SE ELIGE CAPILARIDAD, QUITAMOS LA OPCIÓN DE 'ÚLTIMA PLANTA' DE LA PANTALLA SIGUIENTE
            if(respuestas.problema == 'humedad') {
                $('.ultima_planta_cont').hide();
            }
        }
    });

    // SI NO SE NECESITA ILUMINACIÓN EN UNA NAVE INDUSTRIAL SEGUIMOS CON LA LÓGICA
    $('#no-naveIndustrial').on('click', function() {
        $('#siNaveIndustrial-cont').hide();
        $('#habitaciones-1-2-cont').show();
        $('#siguiente-1-2').show();

        sumatorioSubtotal_1_2 = 0;
    });

    // AÑADIR UNA HABITACIÓN A ILUMINAR
    $('#nueva-habitacion-1-2').on('click', function() {
        if($("#nombre-habitacion-1-2").val() == '' || $("#metros-habitacion-1-2").val() == '' || $("#distancia-cubierta-1-2").val() == '') {
            if($('#pantalla-1-2 .alerta_validacion_input').length == 0) {
                $("#pantalla-1-2 input#nombre-habitacion-1-2, #pantalla-1-2 input#metros-habitacion-1-2, #pantalla-1-2 input#distancia-cubierta-1-2").css("border-color", "#f96171");
                $("#pantalla-1-2 input#nombre-habitacion-1-2, #pantalla-1-2 input#metros-habitacion-1-2, #pantalla-1-2 input#distancia-cubierta-1-2").after("<span class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> Debes rellenar todos los campos</span>");
                $("#pantalla-1-2 .habitacion_input_cont").css("margin-bottom", "1.5em");
            }
        } else {
            if($('.alerta_validacion_input').length > 0) {
                $('.alerta_validacion_input').remove();
                $("#pantalla-1-2 input#nombre-habitacion-1-2, #pantalla-1-2 input#metros-habitacion-1-2, #pantalla-1-2 input#distancia-cubierta-1-2").css("border-color", "#313b12");
                $("#pantalla-1-2 .habitacion_input_cont").css("margin-bottom", "");
            }

            if($("#nombre-habitacion-1-2").val().match(/^[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ\s]+$/)) {
                if($("#metros-habitacion-1-2").val() >= 1) {
                    if($("#distancia-cubierta-1-2").val() >= 1) {
                        var nombreHabitacion_1_2 = $('#nombre-habitacion-1-2').val();
                        var metrosHabitacion_1_2 = $('#metros-habitacion-1-2').val();
                        var distanciaCubierta_1_2 = $('#distancia-cubierta-1-2').val();
                        var kitIluminacion_habitacion_1_2 = '';
                        var precio_kitIluminacion_habitacion_1_2 = 0;

                        if(metrosHabitacion_1_2 < 8) {
                            kitIluminacion_habitacion_1_2 = 'DS160';
                            precio_kitIluminacion_habitacion_1_2 = precioKitDS160;
                            precioTuboIluminacion = precioTuboDS160;
                        } else if(metrosHabitacion_1_2 >= 8) {
                            kitIluminacion_habitacion_1_2 = 'DS290';
                            precio_kitIluminacion_habitacion_1_2 = precioKitDS290;
                            precioTuboIluminacion = precioTuboDS290;
                        }

                        var subtotal_habitacion_1_2 = ((((Math.ceil(parseFloat(distanciaCubierta_1_2)/0.60)) * parseFloat(precioTuboIluminacion)) + parseFloat(precio_kitIluminacion_habitacion_1_2)) + parseFloat(manoObraKitIluminacion));

                        sumatorioSubtotal_1_2 = (parseFloat(sumatorioSubtotal_1_2)+parseFloat(subtotal_habitacion_1_2)).toFixed(2);
                        
                        respuestas.datos_habitaciones_iluminacion.nombre_habitacion.push(nombreHabitacion_1_2);
                        respuestas.datos_habitaciones_iluminacion.metros_habitacion.push(metrosHabitacion_1_2);
                        respuestas.datos_habitaciones_iluminacion.distancia_cubierta.push(distanciaCubierta_1_2);
                        respuestas.datos_habitaciones_iluminacion.kit_iluminacion.push(kitIluminacion_habitacion_1_2);
                        respuestas.datos_habitaciones_iluminacion.precio_kit.push(precio_kitIluminacion_habitacion_1_2);
                        respuestas.datos_habitaciones_iluminacion.subtotal_habitacion.push(parseFloat(subtotal_habitacion_1_2).toFixed(2));
                        respuestas.presupuesto = parseFloat(sumatorioSubtotal_1_2);

                        $('#pantalla-1-2 tbody').append('<tr><td>'+nombreHabitacion_1_2+'</td><td>'+metrosHabitacion_1_2+"</td><td>"+distanciaCubierta_1_2+"</td><td>"+kitIluminacion_habitacion_1_2+"</td></tr>");

                        $('#nombre-habitacion-1-2').val('');
                        $('#metros-habitacion-1-2').val('');
                        $('#distancia-cubierta-1-2').val('');
                    } else {
                        if($('#pantalla-1-2 .alerta_validacion_input').length == 0) {
                            $("#pantalla-1-2 input#distancia-cubierta-1-2").css("border-color", "#f96171");
                            $("#pantalla-1-2 input#distancia-cubierta-1-2").after("<span class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> Introduce un número correcto</span>");
                            $("#pantalla-1-2 .habitacion_input_cont").css("margin-bottom", "1.5em");
                        }
                    }
                } else {
                    if($('#pantalla-1-2 .alerta_validacion_input').length == 0) {
                        $("#pantalla-1-2 input#metros-habitacion-1-2").css("border-color", "#f96171");
                        $("#pantalla-1-2 input#metros-habitacion-1-2").after("<span class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> Introduce un número correcto</span>");
                        $("#pantalla-1-2 .habitacion_input_cont").css("margin-bottom", "1.5em");
                    }
                }
            } else {
                if($('#pantalla-1-2 .alerta_validacion_input').length == 0) {
                    $("#pantalla-1-2 input#nombre-habitacion-1-2").css("border-color", "#f96171");
                    $("#pantalla-1-2 input#nombre-habitacion-1-2").after("<span class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> Debes introducir caracteres correctos</span>");
                    $("#pantalla-1-2 .habitacion_input_cont").css("margin-bottom", "1.5em");
                }
            }
        }
    });

    // LIMPIAR TABLA DE HABITACIONES A ILUMINAR
    $("#limpiar-tabla-1-2").on('click', function() {
        $("#pantalla-1-2 tbody tr").remove();

        respuestas.datos_habitaciones_iluminacion.nombre_habitacion = [];
        respuestas.datos_habitaciones_iluminacion.metros_habitacion = [];
        respuestas.datos_habitaciones_iluminacion.distancia_cubierta = [];
        respuestas.datos_habitaciones_iluminacion.kit_iluminacion = [];
        respuestas.datos_habitaciones_iluminacion.precio_kit = [];
        respuestas.datos_habitaciones_iluminacion.subtotal_habitacion = [];
        respuestas.presupuesto = 0;
        sumatorioSubtotal_1_2 = 0;
    });

    // AL PULSAR EL BOTÓN DE SIGUIENTE DE LA PANTALLA DE HABITACIONES A ILUMINAR
    $('#siguiente-1-2').on('click', function() {
        if($("#pantalla-1-2 tbody").children().length > 0) {
            if($('.alerta_validacion').length > 0) {
                $('.alerta_validacion').remove();
            }
            if($('.alerta_validacion_input').length > 0) {
                $('.alerta_validacion_input').remove();
                $("#pantalla-1-2 input#nombre-habitacion-1-2, #pantalla-1-2 input#metros-habitacion-1-2, #pantalla-1-2 input#distancia-cubierta-1-2").css("border-color", "#313b12");
                $("#pantalla-1-2 .habitacion_input_cont").css("margin-bottom", "");
            }

            respuestas.necesita_iluminacion = true;
            setActiveBreadcrumb('quienEres');
            actualizarPantalla('#pantalla-5');
        } else {
            if($('.alerta_validacion_input').length > 0) {
                $('.alerta_validacion_input').remove();
                $("#pantalla-1-2 input#nombre-habitacion-1-2, #pantalla-1-2 input#metros-habitacion-1-2, #pantalla-1-2 input#distancia-cubierta-1-2").css("border-color", "#313b12");
                $("#pantalla-1-2 .habitacion_input_cont").css("margin-bottom", "");
            }
            if($('.alerta_validacion').length == 0) {
                $("#pantalla-1-2 .botoneria-extremos:has(#siguiente-1-2)").after("<div class='alerta_validacion tabla_habitaciones_vacia'><span class='dashicons dashicons-warning'></span> Debes introducir alguna habitación</div>");
            }
        }
    });

    // AL PULSAR EL BOTÓN DE ATRÁS EN LA PANTALLA DE HABITACIONES A ILUMINAR
    $('#atras-1-2').on('click', function() {
        if($('#pantalla-1-2 .alerta_validacion').length > 0) {
            $('#pantalla-1-2 .alerta_validacion').remove();
        }
        if($('#pantalla-1-2 .alerta_validacion_input').length > 0) {
            $('#pantalla-1-2 .alerta_validacion_input').remove();
            $("#pantalla-1-2 input#nombre-habitacion-1-2, #pantalla-1-2 input#metros-habitacion-1-2, #pantalla-1-2 input#distancia-cubierta-1-2").css("border-color", "#313b12");
            $("#pantalla-1-2 .habitacion_input_cont").css("margin-bottom", "");
        }

        respuestas.datos_habitaciones_iluminacion.nombre_habitacion = [];
        respuestas.datos_habitaciones_iluminacion.metros_habitacion = [];
        respuestas.datos_habitaciones_iluminacion.distancia_cubierta = [];
        respuestas.datos_habitaciones_iluminacion.kit_iluminacion = [];
        respuestas.datos_habitaciones_iluminacion.precio_kit = [];
        respuestas.datos_habitaciones_iluminacion.subtotal_habitacion = [];
        respuestas.presupuesto = 0;
        sumatorioSubtotal_1_2 = 0;

        $("#pantalla-1-2 tbody tr").remove();
        $('#siNaveIndustrial-cont').show();
        $('#habitaciones-1-2-cont').hide();
        $('#siguiente-1-2').hide();

        $("input[name='problema']").prop('checked', false);
        setActiveBreadcrumb('queOcurre');
        actualizarPantalla('#pantalla-1');
    });

    // ABRIR MODAL AL PULSAR EL BOTÓN DE RUIDOS POR IMPACTO
    $("#ruido-impacto").on("click", openModal);
    $("#closeModalBtn").on("click", closeModal);
    window.addEventListener("click", closeModalOnOutsideClick);

    // FUNCIÓN QUE ABRE EL MODAL
    function openModal() {
        document.getElementById("modal-ruidosImpacto").style.display = "block";
    }

    // FUNCIÓN QUE CIERRA EL MODAL
    function closeModal() {
        document.getElementById("modal-ruidosImpacto").style.display = "none";
    }

    // FUNCIÓN QUE CONTROLA QUE EL MODAL SE CIERRE AL PULSAR EN CUALQUIER LUGAR DE LA PANTALLA
    function closeModalOnOutsideClick(event) {
        if (event.target === document.getElementById("modal-ruidosImpacto")) {
            closeModal();
        }
    }

    // ABRIR MODAL AL PULSAR EL BOTÓN DE ILUMINACIÓN DE NAVES INDUSTRIALES
    $("#si-naveIndustrial").on("click", openModalNavesIndustriales);
    $("#closeModalBtnNavesIndustriales").on("click", closeModalNavesIndustriales);
    window.addEventListener("click", closeModalNavesIndustrialesOnOutsideClick);

    // FUNCIÓN QUE ABRE EL MODAL
    function openModalNavesIndustriales() {
        document.getElementById("modal-naveIndustrial").style.display = "block";
    }

    // FUNCIÓN QUE CIERRA EL MODAL
    function closeModalNavesIndustriales() {
        document.getElementById("modal-naveIndustrial").style.display = "none";
    }

    // FUNCIÓN QUE CONTROLA QUE EL MODAL SE CIERRE AL PULSAR EN CUALQUIER LUGAR DE LA PANTALLA
    function closeModalNavesIndustrialesOnOutsideClick(event) {
        if (event.target === document.getElementById("modal-naveIndustrial")) {
            closeModalNavesIndustriales();
        }
    }

    // AL PULSAR EL BOTÓN DE RUIDOS AÉREOS
    $('#ruido-aereo').on('click', function() {
        $('#pantalla-1-3 #tipo-ruidos-cont').hide();
        $('#pantalla-1-3 #localizacion-ruidos-cont').show();
    });

    // AL PULSAR EL BOTÓN DE RUIDOS EN PAREDES
    $('#ruidos-soloPared').on('click', function() {
        $('#pantalla-1-3 #localizacion-ruidos-cont').hide();
        $('#pantalla-1-3 #ruidos-paredes-cont').show();
        $('#siguiente-1-3').show();
    });

    // AL PULSAR EL BOTÓN DE RUIDOS EN EL TECHO
    $('#ruidos-soloTecho').on('click', function() {
        $('#pantalla-1-3 #localizacion-ruidos-cont').hide();
        $('#pantalla-1-3 #ruidos-techo-cont').show();
        $('#siguiente-1-3').show();
    });

    // AL AÑADIR UNA NUEVA HABITACIÓN PARA AISLAR PAREDES
    $('#nueva-pared-1-3').on('click', function() {
        if($("#nombre-paredRuido").val() == '' || $("#metrosAlto-paredRuido").val() == '' || $("#metrosAncho-paredRuido").val() == '') {
            if($('#pantalla-1-3 .alerta_validacion_input').length == 0) {
                $("#pantalla-1-3 input#nombre-paredRuido, #pantalla-1-3 input#metrosAlto-paredRuido, #pantalla-1-3 input#metrosAncho-paredRuido").css("border-color", "#f96171");
                $("#pantalla-1-3 input#nombre-paredRuido, #pantalla-1-3 input#metrosAlto-paredRuido, #pantalla-1-3 input#metrosAncho-paredRuido").after("<span class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> Debes rellenar todos los campos</span>");
                $("#pantalla-1-3 .paredRuido_input_cont").css("margin-bottom", "1.5em");
            }
        } else {
            if($('.alerta_validacion_input').length > 0) {
                $('.alerta_validacion_input').remove();
                $("#pantalla-1-3 input#nombre-paredRuido, #pantalla-1-3 input#metrosAlto-paredRuido, #pantalla-1-3 input#metrosAncho-paredRuido").css("border-color", "#313b12");
                $("#pantalla-1-3 .paredRuido_input_cont").css("margin-bottom", "");
            }

            if($("#nombre-paredRuido").val().match(/^[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ0-9\s]+$/)) {
                if($("#metrosAlto-paredRuido").val() >= 1) {
                    if($("#metrosAncho-paredRuido").val() >= 1) {
                        var nombreParedRuido = $('#nombre-paredRuido').val();
                        var metrosAltoParedRuido = $('#metrosAlto-paredRuido').val();
                        var metrosAnchoParedRuido = $('#metrosAncho-paredRuido').val();
                        var metrosParedRuido = parseFloat(parseFloat(metrosAltoParedRuido) * parseFloat(metrosAnchoParedRuido)).toFixed(2);
            
                        sumatorioMetrosParedes_1_3 = parseFloat(parseFloat(sumatorioMetrosParedes_1_3)+parseFloat(metrosParedRuido)).toFixed(2);
                        
                        respuestas.datos_paredes_aislarRuido.nombre_pared.push(nombreParedRuido);
                        respuestas.datos_paredes_aislarRuido.metros_alto_pared.push(metrosAltoParedRuido);
                        respuestas.datos_paredes_aislarRuido.metros_ancho_pared.push(metrosAnchoParedRuido);
                        respuestas.datos_paredes_aislarRuido.metros_pared.push(metrosParedRuido);

                        $('#pantalla-1-3 tbody').append('<tr><td>'+nombreParedRuido+'</td><td>'+metrosAltoParedRuido+"</td><td>"+metrosAnchoParedRuido+"</td><td>"+metrosParedRuido+"</td></tr>");

                        $('#nombre-paredRuido').val('');
                        $('#metrosAlto-paredRuido').val('');
                        $('#metrosAncho-paredRuido').val('');
                    } else {
                        if($('#pantalla-1-3 .alerta_validacion_input').length == 0) {
                            $("#pantalla-1-3 input#metrosAncho-paredRuido").css("border-color", "#f96171");
                            $("#pantalla-1-3 input#metrosAncho-paredRuido").after("<span class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> Introduce un número correcto</span>");
                            $("#pantalla-1-3 .paredRuido_input_cont").css("margin-bottom", "1.5em");
                        }
                    }
                } else {
                    if($('#pantalla-1-3 .alerta_validacion_input').length == 0) {
                        $("#pantalla-1-3 input#metrosAlto-paredRuido").css("border-color", "#f96171");
                        $("#pantalla-1-3 input#metrosAlto-paredRuido").after("<span class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> Introduce un número correcto</span>");
                        $("#pantalla-1-3 .paredRuido_input_cont").css("margin-bottom", "1.5em");
                    }
                }
            } else {
                if($('#pantalla-1-3 .alerta_validacion_input').length == 0) {
                    $("#pantalla-1-3 input#nombre-paredRuido").css("border-color", "#f96171");
                    $("#pantalla-1-3 input#nombre-paredRuido").after("<span class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> Debes introducir caracteres correctos</span>");
                    $("#pantalla-1-3 .paredRuido_input_cont").css("margin-bottom", "1.5em");
                }
            }
        }
    });

    // LIMPAR TABLA DE HABITACIONES PARA AISLAR PAREDES
    $("#limpiar-tabla-1-3").on('click', function() {
        $("#pantalla-1-3 tbody tr").remove();
        $('.sumatorio_habitaciones').html(0);
        $('.sumatorio_paredesExterior').html(0);
    });

    // AL PULSAR EL BOTÓN DE ATRÁS DE LA PANTALLA DE RUIDOS
    $('#atras-1-3').on('click', function() {
        $('#pantalla-1-3 #ruidos-paredes-cont').hide();
        $('#pantalla-1-3 #ruidos-techo-cont').hide();
        $('#pantalla-1-3 #localizacion-ruidos-cont').hide();
        $('#pantalla-1-3 #tipo-ruidos-cont').show();
        $("#pantalla-1-3 input[type='number']").val('');

        if($('#pantalla-1-3 .alerta_validacion_input').length > 0) {
            $('#pantalla-1-3 .alerta_validacion_input').remove();
            $("#pantalla-1-3 input#nombre-paredRuido, #pantalla-1-3 input#metrosAlto-paredRuido, #pantalla-1-3 input#metrosAncho-paredRuido").css("border-color", "#313b12");
            $("#pantalla-1-3 .paredRuido_input_cont").css("margin-bottom", "");
        }
        $("#pantalla-1-3 input").css("border-color", "#313b12");

        respuestas.datos_paredes_aislarRuido.metros_alto_pared = [];
        respuestas.datos_paredes_aislarRuido.metros_ancho_pared = [];
        respuestas.datos_paredes_aislarRuido.metros_pared = [];
        respuestas.datos_paredes_aislar.nombre_pared = [];
        respuestas.presupuesto = 0;
        sumatorioMetrosParedes_1_3 = 0;

        $("#pantalla-1-3 tbody tr").remove();

        $("input[name='problema']").prop('checked', false);
        setActiveBreadcrumb('queOcurre');
        actualizarPantalla('#pantalla-1');

    });

    // AL PULSAR EL BOTÓN DE SIGUIENTE EN LA PANTALLA DE RUIDOS
    $('#siguiente-1-3').on('click', function() {
        if($('#ruidos-paredes-cont').is(':visible')) {
            
            if($("#pantalla-1-3 tbody").children().length > 0) {
                if($('.alerta_validacion').length > 0) {
                    $('.alerta_validacion').remove();
                }
                if($('.alerta_validacion_input').length > 0) {
                    $('.alerta_validacion_input').remove();
                    $("#pantalla-1-3 input#nombre-paredRuido, #pantalla-1-3 input#metrosAlto-paredRuido, #pantalla-1-3 input#metrosAncho-paredRuido").css("border-color", "#313b12");
                    $("#pantalla-1-3 .paredRuido_input_cont").css("margin-bottom", "");
                }
    
                respuestas.tiene_ruidos = true;
                respuestas.localizacion_ruidos = 'Paredes';
                respuestas.paredes_ruido = parseInt(respuestas.datos_paredes_aislarRuido.nombre_pared.length);
                respuestas.metros_paredes_ruido = parseFloat(sumatorioMetrosParedes_1_3).toFixed(2);
                setActiveBreadcrumb('quienEres');
                actualizarPantalla('#pantalla-5');

            } else {
                if($('.alerta_validacion_input').length > 0) {
                    $('.alerta_validacion_input').remove();
                    $("#pantalla-1-3 input#nombre-paredRuido, #pantalla-1-3 input#metrosAlto-paredRuido, #pantalla-1-3 input#metrosAncho-paredRuido").css("border-color", "#313b12");
                    $("#pantalla-1-3 .paredRuido_input_cont").css("margin-bottom", "");
                }
                if($('.alerta_validacion').length == 0) {
                    $("#pantalla-1-3 .botoneria-extremos:has(#siguiente-1-3)").after("<div class='alerta_validacion tabla_habitaciones_vacia'><span class='dashicons dashicons-warning'></span> Debes introducir alguna pared</div>");
                }
            }

            
        } else if($('#ruidos-techo-cont').is(':visible')) {
            if($('#numHabitaciones-ruidos').val() == '' || $('#metrosHabitaciones-ruidos').val() == '') {
                if($('#pantalla-1-3 .alerta_validacion_input').length == 0) {
                    $("#pantalla-1-3 #datos-techoRuido-cont input").css("border-color", "#f96171");
                    $("#pantalla-1-3 #datos-techoRuido-cont div").has("input").append("<span class='alerta_validacion_input alerta_izquierda'><span class='dashicons dashicons-warning'></span> Debes rellenar todos los campos</span>");
                }
            } else {
                if($('.alerta_validacion_input').length > 0) {
                    $('.alerta_validacion_input').remove();
                }

                if($('#numHabitaciones-ruidos').val() < 1) {
                    if($('#pantalla-1-3 .alerta_validacion_input').length == 0) {
                        $("#pantalla-1-3 #datos-techoRuido-cont input#numHabitaciones-ruidos").css("border-color", "#f96171");
                        $("#pantalla-1-3 #datos-techoRuido-cont div").has("input#numHabitaciones-ruidos").append("<span class='alerta_validacion_input alerta_izquierda'><span class='dashicons dashicons-warning'></span> Introduce un número correcto</span>");
                    }
                } else {
                    if($('#metrosHabitaciones-ruidos').val() < 1) {
                        if($('#pantalla-1-3 .alerta_validacion_input').length == 0) {
                            $("#pantalla-1-3 #datos-techoRuido-cont input#metrosHabitaciones-ruidos").css("border-color", "#f96171");
                            $("#pantalla-1-3 #datos-techoRuido-cont div").has("input#metrosHabitaciones-ruidos").append("<span class='alerta_validacion_input alerta_izquierda'><span class='dashicons dashicons-warning'></span> Introduce un número correcto</span>");
                        }
                    } else {
                        respuestas.tiene_ruidos = true;
                        respuestas.localizacion_ruidos = 'Techos';
                        respuestas.habitaciones_ruido = parseInt($('#numHabitaciones-ruidos').val());
                        respuestas.metros_habitaciones_ruido = parseFloat($('#metrosHabitaciones-ruidos').val());
                        
                        setActiveBreadcrumb('quienEres');
                        actualizarPantalla('#pantalla-5');
                    }
                }
            }
        }
    });

    // AL PULSAR EL BOTÓN DE SIGUIENTE EN LA PANTALLA DE TIPOS DE VIVIENDA
    $('#siguiente-2').on('click', function() {
        if($("input[name='tipo_vivienda']:checked").length == 0) {
            if($('#pantalla-2 .alerta_validacion').length == 0) {
                $("#pantalla-2 h2").after("<div class='alerta_validacion'><span class='dashicons dashicons-warning'></span> Debes seleccionar una opción</div>");
            }
        } else {
            if($('.alerta_validacion').length > 0) {
                $('.alerta_validacion').remove();
            }

            if(respuestas.tipo_vivienda == 'vivienda_independiente' || respuestas.tipo_vivienda == 'ultima_planta') {
                $("#paredes-cubiertas-cont").show();
                actualizarPantalla('#pantalla-3');
            } else if(respuestas.tipo_vivienda == 'local' || respuestas.tipo_vivienda == 'garaje' || respuestas.tipo_vivienda == 'nave_industrial') {
                window.location.href = 'https://eccoaisla.com/contacto';
            } else {
                $("#paredes-cubiertas-cont").hide();
                actualizarPantalla('#pantalla-4');
            }
        }
    });

    // AL PULSAR EL BOTÓN DE ATRÁS EN LA PANTALLA DE TIPOS DE VIVIENDA
    $('#atras-2').on('click', function() {
        if($('#pantalla-2 .alerta_validacion').length > 0) {
            $('#pantalla-2 .alerta_validacion').remove();
        }

        $('.ultima_planta_cont').show();

        $("input[name='problema']").prop('checked', false);
        $("input[name='tipo_vivienda']").prop('checked', false);
        setActiveBreadcrumb('queOcurre');
        actualizarPantalla('#pantalla-1');
    });

    // AL PULSAR EL BOTÓN DE SÓLO AISLAR PAREDES
    $('#si-pared').on('click', function() {
        respuestas.tiene_pared = true;
        respuestas.tiene_cubierta = false;
        respuestas.tiene_cubierta_pared = false;
        actualizarPantalla('#pantalla-4');
    });

    // AL PULSAR EL BOTÓN DE SÓLO AISLAR CUBIERTA
    $('#si-cubierta').on('click', function() {
        respuestas.tiene_cubierta = true;
        respuestas.tiene_pared = false;
        respuestas.tiene_cubierta_pared = false;
        $('#paredes-cubiertas-cont').hide();
        $('#tipo-cubierta-cont').show();
        $('#siguiente-3').show();
    });

    // AL PULSAR EL BOTÓN DE AISLAR PAREDES Y CUBIERTA
    $('#si-paredCubierta').on('click', function() {
        respuestas.tiene_cubierta_pared = true;
        respuestas.tiene_pared = false;
        respuestas.tiene_pared = false;
        $('#paredes-cubiertas-cont').hide();
        $('#tipo-cubierta-cont').show();
        $('#siguiente-3').show();
    });

    // AL PULSAR EL BOTÓN DE SIGUIENTE DE LA PANTALLA DE TIPOS DE CUBIERTA
    $('#siguiente-3').on('click', function() {
        if($("#metros-tejado").val() == '') {
            if($('#pantalla-3 .alerta_validacion_input').length == 0) {
                $("#pantalla-3 input#metros-tejado").css("border-color", "#f96171");
                $("#pantalla-3 p").has("input#metros-tejado").append("<span class='alerta_validacion_input alerta_izquierda'><span class='dashicons dashicons-warning'></span> Debes escribir una cifra</span>");
            }
        } else {
            if($('.alerta_validacion_input').length > 0) {
                $('.alerta_validacion_input').remove();
                $("#pantalla-3 input#metros-tejado").css("border-color", "#313b12");
            }

            if($("#metros-tejado").val() < 1) {
                $("#pantalla-3 input#metros-tejado").css("border-color", "#f96171");
                $("#pantalla-3 p").has("input#metros-tejado").append("<span class='alerta_validacion_input alerta_izquierda'><span class='dashicons dashicons-warning'></span> Escribe un número correcto</span>");
            } else {
                if($("input[name='tipo_cubierta']:checked").length == 0) {
                    if($('#pantalla-3 .alerta_validacion').length == 0) {
                        $("#pantalla-3").append("<div class='alerta_validacion'><span class='dashicons dashicons-warning'></span> Debes seleccionar una opción</div>");
                    }
                } else {
                    if($('.alerta_validacion').length > 0) {
                        $('.alerta_validacion').remove();
                    }
    
                    respuestas.metros_cuadrados_tejado = parseFloat($('#metros-tejado').val());

                    if(respuestas.tiene_cubierta == true && respuestas.tiene_pared == false && respuestas.tiene_cubierta_pared == false) {
                        setActiveBreadcrumb('quienEres');

                        if(respuestas.tipo_cubierta == 'cubierta_tradicional') {
                            $("#pantalla-5 > h2").after(" <div class='banner_tip_verde banner_flex'><div><span class='negrita'>Este presupuesto está calculado con lana mineral</span><span>En algunos casos se puede usar celulosa como material aislante, suponiendo aproximadamente un <span class='negrita'>35% de ahorro</span>. Para saber si su proyecto puede usar celulosa <a href='https://eccoaisla.com/contacto'>póngase en contacto con nuestras oficinas</a>.</span></div></div>");
                        }

                        actualizarPantalla('#pantalla-5');
                    } else if(respuestas.tiene_cubierta_pared == true && respuestas.tiene_cubierta == false && respuestas.tiene_pared == false) {
                        actualizarPantalla('#pantalla-4');
                    }
                }
            }
        }
    });

    // AL PULSAR EL BOTÓN DE ATRÁS DE LA PANTALLA DE TIPOS DE CUBIERTA
    $('#atras-3').on('click', function() {
        if($('#pantalla-3 .alerta_validacion_input').length > 0) {
            $('#pantalla-3 .alerta_validacion_input').remove();
            $("#pantalla-3 input#metros-tejado").css("border-color", "#313b12");
        }

        if($('#pantalla-3 .alerta_validacion').length > 0) {
            $('#pantalla-3 .alerta_validacion').remove();
        }

        $("input[name='tipo_cubierta']").prop('checked', false);
        respuestas.tipo_cubierta = '';
        respuestas.tiene_cubierta = false;
        respuestas.tiene_pared = false;
        respuestas.tiene_cubierta_pared = false;
        $('#tipo-cubierta-cont').hide();
        $('#siguiente-3').hide();
        actualizarPantalla('#pantalla-2');
    });

    // AL AÑADIR UNA NUEVA HABITACIÓN PARA AISLAR PAREDES
    $('#nueva-pared-4').on('click', function() {
        if($("#nombre-pared").val() == '' || $("#metrosAlto-pared").val() == '' || $("#metrosAncho-pared").val() == '') {
            if($('#pantalla-4 .alerta_validacion_input').length == 0) {
                $("#pantalla-4 input#nombre-pared, #pantalla-4 input#metrosAlto-pared, #pantalla-4 input#metrosAncho-pared").css("border-color", "#f96171");
                $("#pantalla-4 input#nombre-pared, #pantalla-4 input#metrosAlto-pared, #pantalla-4 input#metrosAncho-pared").after("<span class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> Debes rellenar todos los campos</span>");
                $("#pantalla-4 .pared_input_cont").css("margin-bottom", "1.5em");
            }
        } else {
            if($('.alerta_validacion_input').length > 0) {
                $('.alerta_validacion_input').remove();
                $("#pantalla-4 input#nombre-pared, #pantalla-4 input#metrosAlto-pared, #pantalla-4 input#metrosAncho-pared").css("border-color", "#313b12");
                $("#pantalla-4 .pared_input_cont").css("margin-bottom", "");
            }

            if($("#nombre-pared").val().match(/^[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ0-9\s]+$/)) {
                if($("#metrosAlto-pared").val() >= 1) {
                    if($("#metrosAncho-pared").val() >= 1) {
                        var nombrePared = $('#nombre-pared').val();
                        var metrosAltoPared = $('#metrosAlto-pared').val();
                        var metrosAnchoPared = $('#metrosAncho-pared').val();
                        var espesorPared = 0.05;
                        var metrosPared = parseFloat(parseFloat(metrosAltoPared) * parseFloat(metrosAnchoPared)).toFixed(2);
                        var metrosCubicosPared = parseFloat((parseFloat(metrosAltoPared) * parseFloat(metrosAnchoPared) * parseFloat(espesorPared))).toFixed(2);
            

                        sumatorioMetrosParedes_4 = parseFloat(parseFloat(sumatorioMetrosParedes_4)+parseFloat(metrosPared)).toFixed(2);
                        sumatorioMetrosCubicosParedes_4 = parseFloat(parseFloat(sumatorioMetrosCubicosParedes_4)+parseFloat(metrosCubicosPared)).toFixed(2);
                        
                        respuestas.datos_paredes_aislar.nombre_pared.push(nombrePared);
                        respuestas.datos_paredes_aislar.metros_alto_pared.push(metrosAltoPared);
                        respuestas.datos_paredes_aislar.metros_ancho_pared.push(metrosAnchoPared);
                        respuestas.datos_paredes_aislar.metros_pared.push(metrosPared);
                        respuestas.datos_paredes_aislar.metros_cubicos_pared.push(metrosCubicosPared);
                        respuestas.datos_paredes_aislar.espesor_pared.push(espesorPared);

                        $('#pantalla-4 tbody').append('<tr><td>'+nombrePared+'</td><td>'+metrosAltoPared+"</td><td>"+metrosAnchoPared+"</td><td>"+metrosPared+"</td></tr>");

                        $('#nombre-pared').val('');
                        $('#metrosAlto-pared').val('');
                        $('#metrosAncho-pared').val('');
                    } else {
                        if($('#pantalla-4 .alerta_validacion_input').length == 0) {
                            $("#pantalla-4 input#metrosAncho-pared").css("border-color", "#f96171");
                            $("#pantalla-4 input#metrosAncho-pared").after("<span class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> Introduce un número correcto</span>");
                            $("#pantalla-4 .pared_input_cont").css("margin-bottom", "1.5em");
                        }
                    }
                } else {
                    if($('#pantalla-4 .alerta_validacion_input').length == 0) {
                        $("#pantalla-4 input#metrosAlto-pared").css("border-color", "#f96171");
                        $("#pantalla-4 input#metrosAlto-pared").after("<span class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> Introduce un número correcto</span>");
                        $("#pantalla-4 .pared_input_cont").css("margin-bottom", "1.5em");
                    }
                }
            } else {
                if($('#pantalla-4 .alerta_validacion_input').length == 0) {
                    $("#pantalla-4 input#nombre-pared").css("border-color", "#f96171");
                    $("#pantalla-4 input#nombre-pared").after("<span class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> Debes introducir caracteres correctos</span>");
                    $("#pantalla-4 .pared_input_cont").css("margin-bottom", "1.5em");
                }
            }
        }
    });

    // LIMPAR TABLA DE HABITACIONES PARA AISLAR PAREDES
    $("#limpiar-tabla").on('click', function() {
        $("#pantalla-4 tbody tr").remove();
        $('.sumatorio_habitaciones').html(0);
        $('.sumatorio_paredesExterior').html(0);
    });

    // AL PULSAR EL BOTÓN DE SIGUIENTE EN LA PANTALLA DE HABITACIONES PARA AISLAR PAREDES
    $('#siguiente-4').on('click', function() {
        if($("#pantalla-4 tbody").children().length > 0) {
            if($('.alerta_validacion').length > 0) {
                $('.alerta_validacion').remove();
            }
            if($('.alerta_validacion_input').length > 0) {
                $('.alerta_validacion_input').remove();
                $("#pantalla-4 input#nombre-pared, #pantalla-4 input#metrosAlto-pared, #pantalla-4 input#metrosAncho-pared").css("border-color", "#313b12");
                $("#pantalla-4 .pared_input_cont").css("margin-bottom", "");
            }

            respuestas.metros_cuadrados = parseFloat(sumatorioMetrosParedes_4).toFixed(2);
            respuestas.metros_cubicos = parseFloat(sumatorioMetrosCubicosParedes_4).toFixed(2);
            setActiveBreadcrumb('quienEres');

            if(respuestas.tipo_cubierta == 'cubierta_tradicional') {
                $("#pantalla-5 > h2").after("<div class='banner_tip_verde banner_flex'><div><span class='negrita'>Este presupuesto está calculado con lana mineral</span><span>En algunos casos se puede usar celulosa como material aislante, suponiendo aproximadamente un <span class='negrita'>35% de ahorro</span>. Para saber si su proyecto puede usar celulosa <a href='https://eccoaisla.com/contacto'>póngase en contacto con nuestras oficinas</a>.</span></div></div>");
            }

            actualizarPantalla('#pantalla-5');
        } else {
            if($('.alerta_validacion_input').length > 0) {
                $('.alerta_validacion_input').remove();
                $("#pantalla-4 input#nombre-pared, #pantalla-4 input#metrosAlto-pared, #pantalla-4 input#metrosAncho-pared").css("border-color", "#313b12");
                $("#pantalla-4 .pared_input_cont").css("margin-bottom", "");
            }
            if($('.alerta_validacion').length == 0) {
                $("#pantalla-4 .botoneria-extremos:has(#siguiente-4)").after("<div class='alerta_validacion tabla_habitaciones_vacia'><span class='dashicons dashicons-warning'></span> Debes introducir alguna pared</div>");
            }
        }
    });

    // AL PULSAR EL BOTÓN DE ATRÁS EN LA PANTALLA DE HABITACIONES PARA AISLAR PAREDES
    $('#atras-4').on('click', function() {
        if($('#pantalla-4 .alerta_validacion').length > 0) {
            $('#pantalla-4 .alerta_validacion').remove();
        }
        if($('#pantalla-4 .alerta_validacion_input').length > 0) {
            $('#pantalla-4 .alerta_validacion_input').remove();
            $("#pantalla-4 input#nombre-pared, #pantalla-4 input#metrosAlto-pared, #pantalla-4 input#metrosAncho-pared").css("border-color", "#313b12");
            $("#pantalla-4 .pared_input_cont").css("margin-bottom", "");
        }

        respuestas.datos_paredes_aislar.espesor_pared = [];
        respuestas.datos_paredes_aislar.metros_alto_pared = [];
        respuestas.datos_paredes_aislar.metros_ancho_pared = [];
        respuestas.datos_paredes_aislar.metros_pared = [];
        respuestas.datos_paredes_aislar.nombre_pared = [];
        respuestas.datos_paredes_aislar.metros_cubicos_pared = [];
        respuestas.presupuesto = 0;
        sumatorioMetrosParedes_4 = 0;
        sumatorioMetrosCubicosParedes_4 = 0;

        $("#pantalla-4 tbody tr").remove();

        if(respuestas.tipo_vivienda == 'vivienda_edificio') {
            actualizarPantalla('#pantalla-2');
        } else if(respuestas.tipo_vivienda == 'vivienda_independiente' || respuestas.tipo_vivienda == 'ultima_planta') {
            actualizarPantalla('#pantalla-3');
        }
    });

    // FUNCIÓN PARA CAPITALIZAR STRINGS
    function capitalizar(cadena) {
        cadena = cadena.trim();
        let palabras = cadena.split(" ");
        for (let i = 0; i < palabras.length; i++) {
            palabras[i] = palabras[i].charAt(0).toUpperCase() + palabras[i].substring(1).toLowerCase();
        }
        return palabras.join(" ");
    }
    
    // AL PULSAR EL BOTÓN DE ENVIAR PRESUPUESTO EN LA PANTALLA DE DATOS PERSONALES
    $('#enviar').on('click', function() {
        if($('#nombre_presupuesto').val() == '' || $('#apellidos_presupuesto').val() == '' || $('#email_presupuesto').val() == '' || $('#telefono_presupuesto').val() == '' || $('#direccion_presupuesto').val() == '' || $('#ciudad_presupuesto').val() == '' || $('#provincia_presupuesto').val() == '') {
            if($('.alerta_validacion').length > 0) {
                $('.alerta_validacion').remove();
            }

            if($('.alerta_validacion').length == 0) {
                $("#pantalla-5 .boton_cont:has(#enviar)").after("<div class='alerta_validacion'><span class='dashicons dashicons-warning'></span> Debes introducir rellenar todos los campos</div>");
            }
        } else {
            if($('.alerta_validacion_input').length > 0) {
                $('.alerta_validacion_input').remove();
                $("#pantalla-5 input#nombre_presupuesto, #pantalla-5 input#apellidos_presupuesto, #pantalla-5 input#email_presupuesto, #pantalla-5 input#telefono_presupuesto, #pantalla-5 input#direccion_presupuesto, #pantalla-5 input#ciudad_presupuesto, #pantalla-5 select#provincia_presupuesto").css("border-color", "#313b12");
            }

            if($('.alerta_validacion').length > 0) {
                $('.alerta_validacion').remove();
            }

            // VALIDACIÓN DE LOS CAMPOS
            if($("#id_holded").html() == "") {
                if($('#nombre_presupuesto').val().match(/^[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ\s\-\']+$/)) {
                    if($('#apellidos_presupuesto').val().match(/^[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ\s\-\']+$/)) {
                        if($('#email_presupuesto').val().match(/^[a-zA-Z0-9\._-]+@[a-zA-Z0-9-]{2,}[.][a-zA-Z]{2,4}$/)) {
                            if($('#telefono_presupuesto').val().match(/^(\+34|0034|34)?[6789]\d{8}$/)) {
                                if($('#ciudad_presupuesto').val().match(/^[a-zA-ZáéíóúàèìòùÀÈÌÒÙÁÉÍÓÚñÑüÜ\s\-\']+$/)) {
                                    if($('.alerta_validacion_input').length > 0) {
                                        $('.alerta_validacion_input').remove();
                                        $("#pantalla-5 input").css("border-color", "#313b12");
                                    }
    
                                    if($('#provincia_presupuesto').val() == "Extremadura/Salamanca/Zamora") {
                                        // Continuar con la operación normal
                                        if($('.alerta_validacion_input').length > 0) {
                                            $('.alerta_validacion_input').remove();
                                            $("#pantalla-5 input").css("border-color", "#313b12");
                                        }

                                        if($('.alerta_validacion').length > 0) {
                                            $('.alerta_validacion').remove();
                                        }

                                        respuestas.nombre = capitalizar($('#nombre_presupuesto').val());
                                        respuestas.apellidos = capitalizar($('#apellidos_presupuesto').val());
                                        respuestas.email = $('#email_presupuesto').val().toLowerCase();
                                        respuestas.telefono = $('#telefono_presupuesto').val();
                                        respuestas.direccion = $('#direccion_presupuesto').val();
                                        respuestas.ciudad = capitalizar($('#ciudad_presupuesto').val());
                                        respuestas.provincia = $('#provincia_presupuesto').val();
                                        if($("#notas_presupuesto").val().length > 0) {
                                            let notasSinEspacio = $("#notas_presupuesto").val().replace(/\n/g, " | ").replace(/"/g, "").replace(/'/g, "").replace(/“/g, "").replace(/”/g, "").replace(/«/g, "").replace(/»/g, "");
                                            respuestas.notas_presupuesto = notasSinEspacio;
                                        }

                                        calcularPresupuesto();
                                        /* setActiveBreadcrumb('tuPresupuesto');
                                        actualizarPantalla('#pantalla-6'); */
                                    } else {
                                        chequearCiudadProvincia($('#ciudad_presupuesto').val(), $('#provincia_presupuesto').val()).then(result => {
                                            if(result) {
                                                if($('.alerta_validacion_input').length > 0) {
                                                    $('.alerta_validacion_input').remove();
                                                    $("#pantalla-5 input").css("border-color", "#313b12");
                                                }

                                                if($('.alerta_validacion').length > 0) {
                                                    $('.alerta_validacion').remove();
                                                }

                                                respuestas.nombre = capitalizar($('#nombre_presupuesto').val());
                                                respuestas.apellidos = capitalizar($('#apellidos_presupuesto').val());
                                                respuestas.email = $('#email_presupuesto').val().toLowerCase();
                                                respuestas.telefono = $('#telefono_presupuesto').val();
                                                respuestas.direccion = $('#direccion_presupuesto').val();
                                                respuestas.ciudad = capitalizar($('#ciudad_presupuesto').val());
                                                respuestas.provincia = $('#provincia_presupuesto').val();
                                                if($("#notas_presupuesto").val().length > 0) {
                                                    let notasSinEspacio = $("#notas_presupuesto").val().replace(/\n/g, " | ").replace(/"/g, "").replace(/'/g, "").replace(/“/g, "").replace(/”/g, "").replace(/«/g, "").replace(/»/g, "");
                                                    respuestas.notas_presupuesto = notasSinEspacio;
                                                }
        
                                                calcularPresupuesto();
                                                /* setActiveBreadcrumb('tuPresupuesto');
                                                actualizarPantalla('#pantalla-6'); */
                                            } else {
                                                if($('.alerta_validacion_input').length > 0) {
                                                    $('.alerta_validacion_input').remove();
                                                    $("#pantalla-5 input").css("border-color", "#313b12");
                                                }

                                                if($('.alerta_validacion').length > 0) {
                                                    $('.alerta_validacion').remove();
                                                }

                                                if($('#pantalla-5 #alerta-ciudad-presupuesto').length == 0) {
                                                    $("#pantalla-5 input#ciudad_presupuesto, #pantalla-5 select#provincia_presupuesto").css("border-color", "#f96171");
                                                    $("#pantalla-5 div").children("input#ciudad_presupuesto").parent().append("<span id='alerta-ciudad-presupuesto' class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> La ciudad no coincide con la provincia</span>");
                                                    $("#pantalla-5 div").children("select#provincia_presupuesto").parent().append("<span id='alerta-provincia-presupuesto' class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> La ciudad no coincide con la provincia</span>");
                                                }
                                            }
                                        }).catch(error => {
                                            console.error("Error al comprobar la ciudad y la provincia: ", error);
                                        });
                                    }
                                } else {
                                    if($('.alerta_validacion_input').length > 0) {
                                        $('.alerta_validacion_input').remove();
                                        $("#pantalla-5 input").css("border-color", "#313b12");
                                    }

                                    if($('.alerta_validacion').length > 0) {
                                        $('.alerta_validacion').remove();
                                    }

                                    if($('#pantalla-5 #alerta-ciudad-presupuesto').length == 0) {
                                        $("#pantalla-5 input#ciudad_presupuesto").css("border-color", "#f96171");
                                        $("#pantalla-5 div").children("input#ciudad_presupuesto").parent().append("<span id='alerta-ciudad-presupuesto' class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> Introduce una ciudad correcta</span>");
                                    }
                                }
                            } else {
                                if($('.alerta_validacion_input').length > 0) {
                                    $('.alerta_validacion_input').remove();
                                    $("#pantalla-5 input").css("border-color", "#313b12");
                                }

                                if($('.alerta_validacion').length > 0) {
                                    $('.alerta_validacion').remove();
                                }

                                if($('#pantalla-5 #alerta-telefono-presupuesto').length == 0) {
                                    $("#pantalla-5 input#telefono_presupuesto").css("border-color", "#f96171");
                                    $("#pantalla-5 div").children("input#telefono_presupuesto").parent().append("<span id='alerta-telefono-presupuesto' class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> Introduce un número de teléfono correcto</span>");
                                }
                            }
                        } else {
                            if($('.alerta_validacion_input').length > 0) {
                                $('.alerta_validacion_input').remove();
                                $("#pantalla-5 input").css("border-color", "#313b12");
                            }

                            if($('.alerta_validacion').length > 0) {
                                $('.alerta_validacion').remove();
                            }

                            if($('#pantalla-5 #alerta-email-presupuesto').length == 0) {
                                $("#pantalla-5 input#email_presupuesto").css("border-color", "#f96171");
                                $("#pantalla-5 div").children("input#email_presupuesto").parent().append("<span id='alerta-email-presupuesto' class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> Introduce un correo electrónico correcto</span>");
                            }
                        }
                    } else {
                        if($('.alerta_validacion_input').length > 0) {
                            $('.alerta_validacion_input').remove();
                            $("#pantalla-5 input").css("border-color", "#313b12");
                        }

                        if($('.alerta_validacion').length > 0) {
                            $('.alerta_validacion').remove();
                        }

                        if($('#pantalla-5 #alerta-apellidos-presupuesto').length == 0) {
                            $("#pantalla-5 input#apellidos_presupuesto").css("border-color", "#f96171");
                            $("#pantalla-5 div").children("input#apellidos_presupuesto").parent().append("<span id='alerta-apellidos-presupuesto' class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> Introduce unos apellidos correctos</span>");
                        }
                    }
                } else {
                    if($('.alerta_validacion').length > 0) {
                        $('.alerta_validacion').remove();
                    }

                    if($('#pantalla-5 #alerta-nombre-presupuesto').length == 0) {
                        $("#pantalla-5 input#nombre_presupuesto").css("border-color", "#f96171");
                        $("#pantalla-5 div").children("input#nombre_presupuesto").parent().append("<span id='alerta-nombre-presupuesto' class='alerta_validacion_input'><span class='dashicons dashicons-warning'></span> Introduce un nombre correcto</span>");
                    }
                }
            } else {
                if($('.alerta_validacion_input').length > 0) {
                    $('.alerta_validacion_input').remove();
                    $("#pantalla-5 input").css("border-color", "#313b12");
                }

                if($('.alerta_validacion').length > 0) {
                    $('.alerta_validacion').remove();
                }

                respuestas.provincia = $('#provincia_presupuesto').val();
                if($("#notas_presupuesto").val().length > 0) {
                    let notasSinEspacio = $("#notas_presupuesto").val().replace(/\n/g, " | ").replace(/"/g, "").replace(/'/g, "").replace(/“/g, "").replace(/”/g, "").replace(/«/g, "").replace(/»/g, "");
                    respuestas.notas_presupuesto = notasSinEspacio;
                }

                calcularPresupuesto();
                /* setActiveBreadcrumb('tuPresupuesto');
                actualizarPantalla('#pantalla-6'); */
            }
        }
    });
});
